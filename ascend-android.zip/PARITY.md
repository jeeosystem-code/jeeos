# Feature parity checklist – web app vs Android APK

Tested in a phone-sized browser before packaging: ✔. Needs a check on a real phone after install: ☐.

| Area | Feature | Status |
|---|---|---|
| Home | Greeting, today card, Practice / Focus / Add task, dock, get-started card | ✔ |
| Plan | Daily planner, add/edit tasks, swipe right = done, swipe left = delete + undo | ✔ ☐ swipe feel |
| Practice | Pick homework or test, ranges, timer, attempted/skipped/correct/wrong, results, redo | ✔ |
| Tests | Folders, single and multi tests, history, analysis | ✔ |
| Homework | Chapters, items, Start, revision flags | ✔ |
| Revision / Keys | Revision list, answer keys | ✔ |
| Syllabus / Tracker / Reports | Chapter tracking, overview, Focus next, reports | ✔ |
| Focus timer | Pomodoro with plan chips, music, home-bar pill | ✔ ☐ keeps running with screen off |
| Sound | Effects, per-category switches, volume, focus music | ✔ ☐ loudness on device |
| Haptics | Vibration with Settings switch (needs VIBRATE permission, added by the build) | ☐ |
| Account | Email sign-in, name, photo, backup status dot | ✔ ☐ sign-in inside the app |
| Cloud sync | Backs up and restores through Firestore | ✔ ☐ on mobile data |
| Backup file | Back up to a file / Restore from a file (APK opens the phone's share sheet) | ☐ |
| Report share | Text share, PDF share | ☐ may fall back to copy/save |
| Offline | Works with no network; sync resumes when back online | ✔ |
| Back button | Closes sheets, goes back one screen, double-press to exit at Home | ✔ ☐ on device |
| Theme | Light, dark, follows phone | ✔ |
| Font | Inter bundled in the APK (no internet needed) | ☐ |
| Names | App is called Ascend; no exam name shown anywhere | ✔ |

First thing to check on a phone: sign in, make a backup, restore it, finish one practice session, close the app and reopen it.
