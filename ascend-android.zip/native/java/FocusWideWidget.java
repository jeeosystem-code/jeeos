package com.ascend.study;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;

public class FocusWideWidget extends AppWidgetProvider {
    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        Wg.render(context, manager, ids, FocusWideWidget.class);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager manager, int id, android.os.Bundle opts) {
        Wg.render(context, manager, new int[]{id}, FocusWideWidget.class);
    }
}
