package com.ascend.study;

import android.Manifest;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.webkit.MimeTypeMap;

import androidx.activity.result.ActivityResult;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Keeps the student's focus music and automatic backups in public folders that survive a reinstall:
 *   Music/Ascend            (user tracks, shown in the Music library of the phone)
 *   Documents/Ascend/Backups (backup files)
 * Android 10+ uses MediaStore (no permission to write); older phones use plain files.
 * Reading what an earlier install left behind needs the audio permission (music) or a folder pick (backups).
 */
@CapacitorPlugin(name = "AscendStorage")
public class AscendStoragePlugin extends Plugin {
    static final int PERM_CODE = 7741;
    static final long MAX_BYTES = 100L * 1024 * 1024;
    static final String MUSIC_REL = "Music/Ascend/";
    static final String DOC_REL = "Documents/Ascend/Backups/";

    static AscendStoragePlugin inst;
    PluginCall permCall;

    @Override
    public void load() {
        inst = this;
    }

    static void onPermResult(int code, String[] perms, int[] res) {
        if (code != PERM_CODE || inst == null) return;
        PluginCall c = inst.permCall;
        inst.permCall = null;
        if (c == null) return;
        boolean ok = res.length > 0;
        for (int r : res) if (r != PackageManager.PERMISSION_GRANTED) ok = false;
        JSObject o = new JSObject();
        o.put("granted", ok);
        c.resolve(o);
    }

    /* ---------- helpers ---------- */

    Context ctx() {
        return getContext();
    }

    ContentResolver cr() {
        return ctx().getContentResolver();
    }

    boolean modern() {
        return Build.VERSION.SDK_INT >= 29;
    }

    Uri audioCol() {
        return modern() ? MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
                : MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
    }

    Uri fileCol() {
        return modern() ? MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL)
                : MediaStore.Files.getContentUri("external");
    }

    String[] wanted() {
        List<String> l = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.READ_MEDIA_AUDIO);
        else l.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        if (Build.VERSION.SDK_INT <= 28) l.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        return l.toArray(new String[0]);
    }

    boolean hasPerm() {
        for (String p : wanted())
            if (ContextCompat.checkSelfPermission(ctx(), p) != PackageManager.PERMISSION_GRANTED) return false;
        return true;
    }

    File legacyDir(String type, String sub) {
        File d = new File(Environment.getExternalStoragePublicDirectory(type), sub);
        if (!d.exists()) d.mkdirs();
        return d;
    }

    static String clean(String n) {
        if (n == null || n.length() == 0) return "track";
        n = n.replace('/', '_').replace('\\', '_').replace(':', '_');
        return n.length() > 120 ? n.substring(n.length() - 120) : n;
    }

    static String ext(String n) {
        int i = n == null ? -1 : n.lastIndexOf('.');
        return i > 0 && n.length() - i <= 6 ? n.substring(i) : "";
    }

    static long copy(InputStream in, OutputStream out) throws Exception {
        byte[] b = new byte[64 * 1024];
        long t = 0;
        int n;
        while ((n = in.read(b)) > 0) {
            out.write(b, 0, n);
            t += n;
        }
        out.flush();
        return t;
    }

    static String text(InputStream in) throws Exception {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        copy(in, o);
        return new String(o.toByteArray(), StandardCharsets.UTF_8);
    }

    String nameOf(Uri u) {
        Cursor c = null;
        try {
            c = cr().query(u, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception e) {
        } finally {
            if (c != null) c.close();
        }
        String p = u.getLastPathSegment();
        return p == null ? "track" : p.substring(p.lastIndexOf('/') + 1);
    }

    long sizeOf(Uri u) {
        Cursor c = null;
        try {
            c = cr().query(u, new String[]{OpenableColumns.SIZE}, null, null, null);
            if (c != null && c.moveToFirst() && !c.isNull(0)) return c.getLong(0);
        } catch (Exception e) {
        } finally {
            if (c != null) c.close();
        }
        return -1;
    }

    String mimeFor(Uri u, String name) {
        String m = null;
        try {
            m = cr().getType(u);
        } catch (Exception e) {
        }
        if (m == null || !m.startsWith("audio/")) {
            String x = ext(name);
            if (x.length() > 1) m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(x.substring(1).toLowerCase());
        }
        return m != null && m.startsWith("audio/") ? m : "audio/mpeg";
    }

    /* ---------- permission ---------- */

    @PluginMethod
    public void status(PluginCall call) {
        JSObject o = new JSObject();
        o.put("sdk", Build.VERSION.SDK_INT);
        o.put("granted", hasPerm());
        call.resolve(o);
    }

    @PluginMethod
    public void askPermission(PluginCall call) {
        if (hasPerm()) {
            JSObject o = new JSObject();
            o.put("granted", true);
            call.resolve(o);
            return;
        }
        if (getActivity() == null) {
            call.reject("no activity");
            return;
        }
        permCall = call;
        ActivityCompat.requestPermissions(getActivity(), wanted(), PERM_CODE);
    }

    /* ---------- music ---------- */

    JSArray musicRows() {
        JSArray arr = new JSArray();
        Cursor c = null;
        try {
            String sel;
            String[] args;
            if (modern()) {
                sel = MediaStore.Audio.Media.RELATIVE_PATH + " LIKE ?";
                args = new String[]{MUSIC_REL + "%"};
            } else {
                sel = MediaStore.Audio.Media.DATA + " LIKE ?";
                args = new String[]{"%/Music/Ascend/%"};
            }
            c = cr().query(audioCol(), new String[]{MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME,
                    MediaStore.Audio.Media.SIZE, MediaStore.Audio.Media.DURATION}, sel, args,
                    MediaStore.Audio.Media.DISPLAY_NAME + " COLLATE NOCASE ASC");
            while (c != null && c.moveToNext()) {
                JSObject o = new JSObject();
                o.put("id", c.getLong(0));
                o.put("name", c.getString(1));
                o.put("size", c.getLong(2));
                o.put("dur", c.isNull(3) ? 0 : c.getLong(3));
                arr.put(o);
            }
        } catch (Exception e) {
        } finally {
            if (c != null) c.close();
        }
        return arr;
    }

    @PluginMethod
    public void musicList(PluginCall call) {
        JSObject o = new JSObject();
        o.put("list", musicRows());
        o.put("granted", hasPerm());
        call.resolve(o);
    }

    /** returns 1 added, 0 skipped as a duplicate, -1 too big, -2 failed */
    int copyIn(Uri src) {
        try {
            String name = clean(nameOf(src));
            long size = sizeOf(src);
            if (size > MAX_BYTES) return -1;
            JSArray have = musicRows();
            for (int i = 0; i < have.length(); i++) {
                JSObject h = JSObject.fromJSONObject(have.getJSONObject(i));
                if (name.equalsIgnoreCase(h.getString("name")) && (size < 0 || size == h.getLong("size"))) return 0;
            }
            InputStream in = cr().openInputStream(src);
            if (in == null) return -2;
            try {
                if (modern()) {
                    ContentValues cv = new ContentValues();
                    cv.put(MediaStore.Audio.Media.DISPLAY_NAME, name);
                    cv.put(MediaStore.Audio.Media.MIME_TYPE, mimeFor(src, name));
                    cv.put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/Ascend");
                    cv.put(MediaStore.Audio.Media.IS_PENDING, 1);
                    Uri out = cr().insert(audioCol(), cv);
                    if (out == null) return -2;
                    try {
                        OutputStream os = cr().openOutputStream(out);
                        if (os == null) throw new Exception("no stream");
                        try {
                            copy(in, os);
                        } finally {
                            os.close();
                        }
                        ContentValues done = new ContentValues();
                        done.put(MediaStore.Audio.Media.IS_PENDING, 0);
                        cr().update(out, done, null, null);
                    } catch (Exception e) {
                        try {
                            cr().delete(out, null, null);
                        } catch (Exception x) {
                        }
                        return -2;
                    }
                } else {
                    File f = new File(legacyDir(Environment.DIRECTORY_MUSIC, "Ascend"), name);
                    FileOutputStream os = new FileOutputStream(f);
                    try {
                        copy(in, os);
                    } finally {
                        os.close();
                    }
                    MediaScannerConnection.scanFile(ctx(), new String[]{f.getPath()}, null, null);
                }
            } finally {
                in.close();
            }
            return 1;
        } catch (Exception e) {
            return -2;
        }
    }

    JSObject importAll(List<Uri> uris) {
        int added = 0, dup = 0, big = 0, bad = 0;
        for (Uri u : uris) {
            int r = copyIn(u);
            if (r == 1) added++;
            else if (r == 0) dup++;
            else if (r == -1) big++;
            else bad++;
        }
        JSObject o = new JSObject();
        o.put("added", added);
        o.put("dup", dup);
        o.put("big", big);
        o.put("bad", bad);
        o.put("list", musicRows());
        return o;
    }

    @PluginMethod
    public void musicPick(PluginCall call) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("audio/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(call, i, "musicPicked");
    }

    @ActivityCallback
    private void musicPicked(final PluginCall call, ActivityResult result) {
        if (call == null) return;
        Intent d = result == null ? null : result.getData();
        if (d == null) {
            JSObject o = new JSObject();
            o.put("cancelled", true);
            o.put("list", musicRows());
            call.resolve(o);
            return;
        }
        final List<Uri> uris = new ArrayList<>();
        if (d.getClipData() != null) {
            for (int k = 0; k < d.getClipData().getItemCount(); k++) uris.add(d.getClipData().getItemAt(k).getUri());
        } else if (d.getData() != null) {
            uris.add(d.getData());
        }
        new Thread(new Runnable() {
            public void run() {
                call.resolve(importAll(uris));
            }
        }).start();
    }

    @PluginMethod
    public void musicImport(final PluginCall call) {
        final List<Uri> uris = new ArrayList<>();
        try {
            JSArray a = call.getArray("uris");
            for (int i = 0; a != null && i < a.length(); i++) uris.add(Uri.parse(a.getString(i)));
        } catch (Exception e) {
        }
        new Thread(new Runnable() {
            public void run() {
                call.resolve(importAll(uris));
            }
        }).start();
    }

    /** Copies the track into the app cache and returns a path the web view can play. */
    @PluginMethod
    public void musicFile(final PluginCall call) {
        final long id = call.getData().optLong("id", -1L);
        if (id < 0) {
            call.reject("no id");
            return;
        }
        new Thread(new Runnable() {
            public void run() {
                try {
                    Uri u = ContentUris.withAppendedId(audioCol(), id);
                    String name = clean(nameOf(u));
                    long size = sizeOf(u);
                    File dir = new File(ctx().getCacheDir(), "music");
                    if (!dir.exists()) dir.mkdirs();
                    File f = new File(dir, "mu" + id + "_" + size + ext(name));
                    if (!f.exists() || (size > 0 && f.length() != size)) {
                        File tmp = new File(dir, f.getName() + ".part");
                        InputStream in = cr().openInputStream(u);
                        if (in == null) {
                            call.reject("can't open the track (no stream)");
                            return;
                        }
                        FileOutputStream os = new FileOutputStream(tmp);
                        try {
                            copy(in, os);
                        } finally {
                            os.close();
                            in.close();
                        }
                        if (f.exists()) f.delete();
                        tmp.renameTo(f);
                    }
                    JSObject o = new JSObject();
                    o.put("path", f.getAbsolutePath());
                    call.resolve(o);
                } catch (Exception e) {
                    call.reject("can't open the track: " + e);
                }
            }
        }).start();
    }

    /** Fallback: hands the whole track to the page as base64 (for tracks up to 40 MB). */
    @PluginMethod
    public void musicRead(final PluginCall call) {
        final long id = call.getData().optLong("id", -1L);
        new Thread(new Runnable() {
            public void run() {
                try {
                    Uri u = ContentUris.withAppendedId(audioCol(), id);
                    InputStream in = cr().openInputStream(u);
                    if (in == null) {
                        call.reject("can't open the track (no stream)");
                        return;
                    }
                    ByteArrayOutputStream bo = new ByteArrayOutputStream();
                    try {
                        long n = copy(in, bo);
                        if (n > 40L * 1024 * 1024) {
                            call.reject("track too big for the fallback");
                            return;
                        }
                    } finally {
                        in.close();
                    }
                    JSObject o = new JSObject();
                    o.put("data", Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP));
                    o.put("mime", mimeFor(u, nameOf(u)));
                    call.resolve(o);
                } catch (Exception e) {
                    call.reject("can't read the track: " + e);
                }
            }
        }).start();
    }

    @PluginMethod
    public void musicDelete(PluginCall call) {
        long id = call.getData().optLong("id", -1L);
        try {
            int n = cr().delete(ContentUris.withAppendedId(audioCol(), id), null, null);
            JSObject o = new JSObject();
            o.put("deleted", n > 0);
            o.put("list", musicRows());
            call.resolve(o);
        } catch (Exception e) {
            call.reject("Android did not allow deleting that file. Delete it in your Files app.");
        }
    }

    /* ---------- backups ---------- */

    long fileId(String name) {
        Cursor c = null;
        try {
            c = cr().query(fileCol(), new String[]{MediaStore.Files.FileColumns._ID},
                    MediaStore.Files.FileColumns.RELATIVE_PATH + "=? AND " + MediaStore.Files.FileColumns.DISPLAY_NAME + "=?",
                    new String[]{DOC_REL, name}, null);
            if (c != null && c.moveToFirst()) return c.getLong(0);
        } catch (Exception e) {
        } finally {
            if (c != null) c.close();
        }
        return -1;
    }

    JSArray backupRows() {
        JSArray arr = new JSArray();
        try {
            if (modern()) {
                Cursor c = cr().query(fileCol(), new String[]{MediaStore.Files.FileColumns.DISPLAY_NAME,
                                MediaStore.Files.FileColumns.SIZE, MediaStore.Files.FileColumns.DATE_MODIFIED},
                        MediaStore.Files.FileColumns.RELATIVE_PATH + "=?", new String[]{DOC_REL}, null);
                try {
                    while (c != null && c.moveToNext()) {
                        String n = c.getString(0);
                        if (n == null || n.startsWith("tmp-")) continue;
                        JSObject o = new JSObject();
                        o.put("name", n);
                        o.put("size", c.getLong(1));
                        o.put("ms", c.getLong(2) * 1000L);
                        arr.put(o);
                    }
                } finally {
                    if (c != null) c.close();
                }
            } else {
                File[] fs = legacyDir(Environment.DIRECTORY_DOCUMENTS, "Ascend/Backups").listFiles();
                if (fs != null) for (File f : fs) {
                    if (!f.isFile() || f.getName().startsWith("tmp-")) continue;
                    JSObject o = new JSObject();
                    o.put("name", f.getName());
                    o.put("size", f.length());
                    o.put("ms", f.lastModified());
                    arr.put(o);
                }
            }
        } catch (Exception e) {
        }
        return arr;
    }

    @PluginMethod
    public void backupList(PluginCall call) {
        JSObject o = new JSObject();
        o.put("list", backupRows());
        call.resolve(o);
    }

    @PluginMethod
    public void backupWrite(final PluginCall call) {
        final String name = clean(call.getString("name"));
        final String data = call.getString("data");
        if (data == null || !name.endsWith(".json")) {
            call.reject("bad file");
            return;
        }
        new Thread(new Runnable() {
            public void run() {
                try {
                    byte[] bytes = data.getBytes(StandardCharsets.UTF_8);
                    String tmpName = "tmp-" + name;
                    if (modern()) {
                        long old = fileId(tmpName);
                        if (old >= 0) {
                            try {
                                cr().delete(ContentUris.withAppendedId(fileCol(), old), null, null);
                            } catch (Exception e) {
                            }
                        }
                        ContentValues cv = new ContentValues();
                        cv.put(MediaStore.Files.FileColumns.DISPLAY_NAME, tmpName);
                        cv.put(MediaStore.Files.FileColumns.MIME_TYPE, "application/json");
                        cv.put(MediaStore.Files.FileColumns.RELATIVE_PATH, "Documents/Ascend/Backups");
                        cv.put(MediaStore.Files.FileColumns.IS_PENDING, 1);
                        Uri out = cr().insert(fileCol(), cv);
                        if (out == null) throw new Exception("insert failed");
                        try {
                            OutputStream os = cr().openOutputStream(out, "wt");
                            if (os == null) throw new Exception("no stream");
                            try {
                                os.write(bytes);
                                os.flush();
                            } finally {
                                os.close();
                            }
                            ContentValues done = new ContentValues();
                            done.put(MediaStore.Files.FileColumns.IS_PENDING, 0);
                            cr().update(out, done, null, null);
                        } catch (Exception e) {
                            try {
                                cr().delete(out, null, null);
                            } catch (Exception x) {
                            }
                            throw e;
                        }
                        /* the new copy is complete: now replace the old one */
                        long prev = fileId(name);
                        if (prev >= 0) {
                            try {
                                cr().delete(ContentUris.withAppendedId(fileCol(), prev), null, null);
                            } catch (Exception e) {
                            }
                        }
                        ContentValues rn = new ContentValues();
                        rn.put(MediaStore.Files.FileColumns.DISPLAY_NAME, name);
                        try {
                            cr().update(out, rn, null, null);
                        } catch (Exception e) {
                        }
                    } else {
                        File dir = legacyDir(Environment.DIRECTORY_DOCUMENTS, "Ascend/Backups");
                        File tmp = new File(dir, tmpName);
                        FileOutputStream os = new FileOutputStream(tmp);
                        try {
                            os.write(bytes);
                            os.flush();
                        } finally {
                            os.close();
                        }
                        File dst = new File(dir, name);
                        if (dst.exists()) dst.delete();
                        if (!tmp.renameTo(dst)) throw new Exception("rename failed");
                    }
                    JSObject o = new JSObject();
                    o.put("ok", true);
                    call.resolve(o);
                } catch (Exception e) {
                    call.reject("backup failed");
                }
            }
        }).start();
    }

    @PluginMethod
    public void backupRead(PluginCall call) {
        String name = clean(call.getString("name"));
        try {
            String t;
            if (modern()) {
                long id = fileId(name);
                if (id < 0) {
                    call.reject("not found");
                    return;
                }
                InputStream in = cr().openInputStream(ContentUris.withAppendedId(fileCol(), id));
                if (in == null) {
                    call.reject("not found");
                    return;
                }
                try {
                    t = text(in);
                } finally {
                    in.close();
                }
            } else {
                FileInputStream in = new FileInputStream(new File(legacyDir(Environment.DIRECTORY_DOCUMENTS, "Ascend/Backups"), name));
                try {
                    t = text(in);
                } finally {
                    in.close();
                }
            }
            JSObject o = new JSObject();
            o.put("data", t);
            call.resolve(o);
        } catch (Exception e) {
            call.reject("can't read");
        }
    }

    @PluginMethod
    public void backupDelete(PluginCall call) {
        String name = clean(call.getString("name"));
        try {
            boolean ok;
            if (modern()) {
                long id = fileId(name);
                ok = id >= 0 && cr().delete(ContentUris.withAppendedId(fileCol(), id), null, null) > 0;
            } else {
                ok = new File(legacyDir(Environment.DIRECTORY_DOCUMENTS, "Ascend/Backups"), name).delete();
            }
            JSObject o = new JSObject();
            o.put("deleted", ok);
            call.resolve(o);
        } catch (Exception e) {
            call.reject("can't delete");
        }
    }

    /* ---------- picking a folder (needed after a reinstall to read files the old install made) ---------- */

    @PluginMethod
    public void treePick(PluginCall call) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        startActivityForResult(call, i, "treePicked");
    }

    void walk(Uri tree, String docId, int depth, JSArray out) {
        if (depth > 3 || out.length() > 300) return;
        Cursor c = null;
        try {
            Uri kids = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId);
            c = cr().query(kids, new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE,
                    DocumentsContract.Document.COLUMN_SIZE, DocumentsContract.Document.COLUMN_LAST_MODIFIED}, null, null, null);
            List<String[]> dirs = new ArrayList<>();
            while (c != null && c.moveToNext()) {
                String id = c.getString(0), nm = c.getString(1), mime = c.getString(2);
                if (DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) {
                    dirs.add(new String[]{id});
                    continue;
                }
                JSObject o = new JSObject();
                o.put("name", nm);
                o.put("mime", mime);
                o.put("size", c.isNull(3) ? 0 : c.getLong(3));
                o.put("ms", c.isNull(4) ? 0 : c.getLong(4));
                o.put("uri", DocumentsContract.buildDocumentUriUsingTree(tree, id).toString());
                out.put(o);
            }
            c.close();
            c = null;
            for (String[] d : dirs) walk(tree, d[0], depth + 1, out);
        } catch (Exception e) {
        } finally {
            if (c != null) c.close();
        }
    }

    @ActivityCallback
    private void treePicked(final PluginCall call, ActivityResult result) {
        if (call == null) return;
        Intent d = result == null ? null : result.getData();
        if (d == null || d.getData() == null) {
            JSObject o = new JSObject();
            o.put("cancelled", true);
            call.resolve(o);
            return;
        }
        final Uri tree = d.getData();
        try {
            cr().takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception e) {
        }
        new Thread(new Runnable() {
            public void run() {
                JSArray files = new JSArray();
                walk(tree, DocumentsContract.getTreeDocumentId(tree), 0, files);
                JSObject o = new JSObject();
                o.put("files", files);
                call.resolve(o);
            }
        }).start();
    }

    @PluginMethod
    public void treeRead(PluginCall call) {
        try {
            InputStream in = cr().openInputStream(Uri.parse(call.getString("uri")));
            if (in == null) {
                call.reject("can't read");
                return;
            }
            String t;
            try {
                t = text(in);
            } finally {
                in.close();
            }
            JSObject o = new JSObject();
            o.put("data", t);
            call.resolve(o);
        } catch (Exception e) {
            call.reject("can't read");
        }
    }
}
