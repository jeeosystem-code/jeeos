package com.ascend.study;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.SystemClock;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Draws all five Ascend widgets from the summary the web app saves. */
public class Wg {
    static final String PREFS = "ascend_wg";

    static final Class<?>[] PROVIDERS = {
        TodayWidget.class, FocusWidget.class, ResumeWidget.class, TargetWidget.class, ReviseWidget.class
    };

    /* ---------- storage and refresh ---------- */

    static void store(Context c, String json) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("json", json).apply();
    }

    static JSONObject snap(Context c) {
        try {
            String j = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("json", null);
            return j == null ? null : new JSONObject(j);
        } catch (Exception e) {
            return null;
        }
    }

    static void refreshAll(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        for (Class<?> k : PROVIDERS) {
            int[] ids = m.getAppWidgetIds(new ComponentName(c, k));
            if (ids != null && ids.length > 0) render(c, m, ids, k);
        }
    }

    static void render(Context c, AppWidgetManager m, int[] ids, Class<?> kind) {
        JSONObject s = snap(c);
        for (int id : ids) {
            try {
                RemoteViews rv;
                if (kind == TodayWidget.class) rv = today(c, s);
                else if (kind == FocusWidget.class) rv = focus(c, s);
                else if (kind == ResumeWidget.class) rv = resume(c, s);
                else if (kind == TargetWidget.class) rv = target(c, s);
                else rv = revise(c, s);
                m.updateAppWidget(id, rv);
            } catch (Exception e) {
                /* a widget must never crash the launcher: leave the last picture */
            }
        }
    }

    /* ---------- theme ---------- */

    static class P {
        boolean dark;
        int text, sec, accent, track, red, green, onAccent;
        int cardBg, accentBg, chipBg, circBg;
    }

    static P pal(JSONObject s) {
        P p = new P();
        p.dark = s != null && s.optBoolean("dark");
        if (p.dark) {
            p.text = 0xFFF1F3FB; p.sec = 0xFF98A0B8; p.accent = 0xFF8E8CFF; p.track = 0xFF262C44;
            p.red = 0xFFF0906F; p.green = 0xFF7FD0A0; p.onAccent = 0xFF10122A;
            p.cardBg = R.drawable.w_card_d; p.accentBg = R.drawable.w_accent_d;
            p.chipBg = R.drawable.w_chip_d; p.circBg = R.drawable.w_circ_d;
        } else {
            p.text = 0xFF1B1A17; p.sec = 0xFF6B7388; p.accent = 0xFF5E5CE6; p.track = 0xFFE3E8F4;
            p.red = 0xFFC8553A; p.green = 0xFF2F8F5B; p.onAccent = 0xFFFFFFFF;
            p.cardBg = R.drawable.w_card_l; p.accentBg = R.drawable.w_accent_l;
            p.chipBg = R.drawable.w_chip_l; p.circBg = R.drawable.w_circ_l;
        }
        return p;
    }

    /* ---------- helpers ---------- */

    static int dp(Context c, float v) {
        return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f);
    }

    static PendingIntent link(Context c, String uri) {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(uri), c, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getActivity(c, uri.hashCode(), i, flags);
    }

    static void txt(RemoteViews rv, int id, CharSequence t, int color) {
        rv.setTextViewText(id, t);
        rv.setTextColor(id, color);
    }

    static void show(RemoteViews rv, int id, boolean on) {
        rv.setViewVisibility(id, on ? View.VISIBLE : View.GONE);
    }

    static String clip(String t, int n) {
        if (t == null) return "";
        return t.length() <= n ? t : t.substring(0, n - 1) + "…";
    }

    static int color(String hex, int fallback) {
        try { return android.graphics.Color.parseColor(hex); } catch (Exception e) { return fallback; }
    }

    static Bitmap ring(Context c, int sizeDp, float frac, int track, int col, String center, int textCol, float textSp) {
        int px = dp(c, sizeDp);
        Bitmap b = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float sw = px * 0.11f;
        RectF r = new RectF(sw / 2, sw / 2, px - sw / 2, px - sw / 2);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(sw);
        p.setColor(track);
        cv.drawArc(r, 0, 360, false, p);
        if (frac > 0) {
            p.setColor(col);
            p.setStrokeCap(Paint.Cap.ROUND);
            cv.drawArc(r, -90, 360f * Math.min(1f, frac), false, p);
        }
        if (center != null) {
            Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
            t.setColor(textCol);
            Typeface tf = null;
            try { tf = androidx.core.content.res.ResourcesCompat.getFont(c, R.font.sora_bold); } catch (Exception e) { }
            t.setTypeface(tf != null ? tf : Typeface.DEFAULT_BOLD);
            t.setTextAlign(Paint.Align.CENTER);
            t.setTextSize(textSp * c.getResources().getDisplayMetrics().scaledDensity);
            float y = px / 2f - (t.ascent() + t.descent()) / 2f;
            cv.drawText(center, px / 2f, y, t);
        }
        return b;
    }

    static Bitmap bars(Context c, int wDp, int hDp, double[] v, String letters, P p) {
        int w = dp(c, wDp), h = dp(c, hDp);
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
        t.setColor(p.sec);
        t.setTextAlign(Paint.Align.CENTER);
        t.setTextSize(10 * c.getResources().getDisplayMetrics().scaledDensity);
        int n = v.length;
        double mx = 1;
        for (double d : v) mx = Math.max(mx, d);
        float gap = dp(c, 5);
        float bw = (w - gap * (n - 1)) / n;
        float labelH = dp(c, 14);
        float top = 0, base = h - labelH;
        for (int i = 0; i < n; i++) {
            float x = i * (bw + gap);
            float bh = (float) Math.max(dp(c, 3), (base - top) * v[i] / mx);
            paint.setColor(i == n - 1 ? p.accent : (p.dark ? 0xFF4A4C86 : 0xFFB9B8F2));
            cv.drawRoundRect(new RectF(x, base - bh, x + bw, base), dp(c, 3), dp(c, 3), paint);
            String l = i < letters.length() ? String.valueOf(letters.charAt(i)) : "";
            cv.drawText(l, x + bw / 2, h - dp(c, 2), t);
        }
        return b;
    }

    /* ---------- Today (4x2) ---------- */

    static RemoteViews today(Context c, JSONObject s) {
        P p = pal(s);
        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.w_today);
        rv.setInt(R.id.root, "setBackgroundResource", p.cardBg);
        rv.setOnClickPendingIntent(R.id.root, link(c, "ascend://today"));
        rv.setOnClickPendingIntent(R.id.t_add, link(c, "ascend://add"));
        rv.setInt(R.id.t_add, "setBackgroundResource", p.accentBg);
        rv.setTextColor(R.id.t_add, p.onAccent);
        int[] rows = {R.id.t_r1, R.id.t_r2};
        int[] dots = {R.id.t_d1, R.id.t_d2};
        int[] ti = {R.id.t_t1, R.id.t_t2};
        int[] su = {R.id.t_s1, R.id.t_s2};
        int[] pl = {R.id.t_p1, R.id.t_p2};
        txt(rv, R.id.t_title, "Today", p.text);
        for (int i = 0; i < 2; i++) show(rv, rows[i], false);
        show(rv, R.id.t_more, false);
        show(rv, R.id.t_empty, false);

        JSONObject td = s == null ? null : s.optJSONObject("today");
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        boolean fresh = s != null && today.equals(s.optString("d"));
        if (td == null || !fresh) {
            rv.setImageViewBitmap(R.id.t_ring, ring(c, 44, 0f, p.track, p.accent, null, p.text, 12));
            txt(rv, R.id.t_sub, td == null ? "Open Ascend to set up" : "Open Ascend to refresh", p.sec);
            return rv;
        }
        int n = td.optInt("n"), dn = td.optInt("dn"), od = td.optInt("od");
        rv.setImageViewBitmap(R.id.t_ring, ring(c, 44, n > 0 ? (float) dn / n : 0f, p.track, p.accent, n > 0 ? dn + "/" + n : "0", p.text, 12));
        String base = n == 0 ? "Nothing planned" : dn + " of " + n + " done";
        if (od > 0) {
            String full = base + " · " + od + " overdue";
            SpannableString sp = new SpannableString(full);
            int st = base.length() + 3;
            sp.setSpan(new ForegroundColorSpan(p.red), st, full.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            txt(rv, R.id.t_sub, sp, p.sec);
        } else {
            txt(rv, R.id.t_sub, base, p.sec);
        }
        JSONArray items = td.optJSONArray("items");
        int cnt = items == null ? 0 : items.length();
        if (cnt == 0) {
            txt(rv, R.id.t_empty, n == 0 ? "Tap + to plan your day" : "All done for today", p.sec);
            show(rv, R.id.t_empty, true);
            return rv;
        }
        for (int i = 0; i < Math.min(2, cnt); i++) {
            JSONObject it = items.optJSONObject(i);
            if (it == null) continue;
            show(rv, rows[i], true);
            rv.setInt(dots[i], "setColorFilter", color(it.optString("c"), p.accent));
            txt(rv, ti[i], clip(it.optString("t"), 34), p.text);
            String sub = it.optString("s");
            String tm = it.optString("tm");
            String line = sub.length() > 0 && tm.length() > 0 ? sub + " · " + tm : sub + tm;
            txt(rv, su[i], line, p.sec);
            rv.setInt(pl[i], "setBackgroundResource", p.circBg);
            rv.setTextColor(pl[i], p.accent);
            rv.setOnClickPendingIntent(pl[i], link(c, "ascend://focus?start=1"));
        }
        int left = (td.optInt("n") - td.optInt("dn")) - 2;
        if (left > 0) {
            txt(rv, R.id.t_more, "+" + left + " more", p.sec);
            show(rv, R.id.t_more, true);
        }
        return rv;
    }

    /* ---------- Focus (2x2) ---------- */

    static RemoteViews focus(Context c, JSONObject s) {
        P p = pal(s);
        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.w_focus);
        rv.setInt(R.id.root, "setBackgroundResource", p.cardBg);
        JSONObject f = s == null ? null : s.optJSONObject("focus");
        boolean on = f != null && f.optBoolean("on");
        boolean run = on && f.optBoolean("run");
        String ph = f == null ? "idle" : f.optString("ph", "idle");
        long end = f == null ? 0 : f.optLong("end");
        long left = f == null ? 0 : f.optLong("left");
        int st = f == null ? 0 : f.optInt("st");
        int mins = f == null ? 25 : Math.max(1, f.optInt("f", 25));
        long now = System.currentTimeMillis();
        boolean brk = "short".equals(ph) || "long".equals(ph);
        show(rv, R.id.f_chrono, false);
        txt(rv, R.id.f_label, "Focus", p.sec);

        if (!on) {
            rv.setImageViewBitmap(R.id.f_ring, ring(c, 92, 0f, p.track, p.accent, null, p.text, 20));
            txt(rv, R.id.f_mid, "Start", p.accent);
            rv.setTextViewTextSize(R.id.f_mid, 2, 22);
            txt(rv, R.id.f_foot, st > 0 ? st + (st == 1 ? " day streak" : " day streak") : mins + " min block", p.sec);
            rv.setOnClickPendingIntent(R.id.root, link(c, "ascend://focus?start=1"));
            show(rv, R.id.f_mid, true);
            return rv;
        }
        rv.setOnClickPendingIntent(R.id.root, link(c, "ascend://focus"));
        txt(rv, R.id.f_label, brk ? "Break" : "Focus · block " + Math.max(1, f.optInt("n")) + " of " + Math.max(1, f.optInt("e", 4)), p.sec);
        if (run && end > now) {
            rv.setImageViewBitmap(R.id.f_ring, ring(c, 92, 1f, p.track, brk ? p.green : p.accent, null, p.text, 20));
            show(rv, R.id.f_mid, false);
            if (Build.VERSION.SDK_INT >= 24) {
                show(rv, R.id.f_chrono, true);
                long base = SystemClock.elapsedRealtime() + (end - now);
                rv.setChronometerCountDown(R.id.f_chrono, true);
                rv.setChronometer(R.id.f_chrono, base, null, true);
                rv.setTextColor(R.id.f_chrono, p.text);
            } else {
                long sec = (end - now) / 1000;
                txt(rv, R.id.f_mid, String.format(Locale.US, "%d:%02d", sec / 60, sec % 60), p.text);
                show(rv, R.id.f_mid, true);
            }
            txt(rv, R.id.f_foot, brk ? "Rest up" : "Keep going", p.sec);
        } else if (run) {
            rv.setImageViewBitmap(R.id.f_ring, ring(c, 92, 1f, p.track, p.green, null, p.text, 20));
            txt(rv, R.id.f_mid, "Done", p.green);
            show(rv, R.id.f_mid, true);
            txt(rv, R.id.f_foot, "Open to continue", p.sec);
        } else {
            long sec = left / 1000;
            rv.setImageViewBitmap(R.id.f_ring, ring(c, 92, 0.5f, p.track, p.sec, null, p.text, 20));
            txt(rv, R.id.f_mid, String.format(Locale.US, "%d:%02d", sec / 60, sec % 60), p.text);
            show(rv, R.id.f_mid, true);
            txt(rv, R.id.f_foot, "Paused", p.sec);
        }
        return rv;
    }

    /* ---------- Resume (4x1) ---------- */

    static RemoteViews resume(Context c, JSONObject s) {
        P p = pal(s);
        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.w_resume);
        rv.setInt(R.id.root, "setBackgroundResource", p.cardBg);
        rv.setInt(R.id.r_btn, "setBackgroundResource", p.accentBg);
        rv.setTextColor(R.id.r_btn, p.onAccent);
        JSONObject r = s == null ? null : s.optJSONObject("resume");
        if (r == null) {
            rv.setImageViewBitmap(R.id.r_ring, ring(c, 42, 0f, p.track, p.green, null, p.text, 11));
            txt(rv, R.id.r_label, "Practice", p.sec);
            txt(rv, R.id.r_title, "No unfinished session", p.text);
            txt(rv, R.id.r_sub, "Start a timed set", p.sec);
            rv.setTextViewText(R.id.r_btn, "Start");
            PendingIntent pi = link(c, "ascend://practice");
            rv.setOnClickPendingIntent(R.id.root, pi);
            rv.setOnClickPendingIntent(R.id.r_btn, pi);
            return rv;
        }
        int dn = r.optInt("dn"), t = Math.max(1, r.optInt("t"));
        rv.setImageViewBitmap(R.id.r_ring, ring(c, 42, (float) dn / t, p.track, p.green, null, p.text, 11));
        txt(rv, R.id.r_label, "Unfinished " + r.optString("k", "session").toLowerCase(Locale.US), p.sec);
        txt(rv, R.id.r_title, clip(r.optString("n", "Session"), 28), p.text);
        txt(rv, R.id.r_sub, dn + " of " + t + " answered", p.sec);
        rv.setTextViewText(R.id.r_btn, "Continue");
        PendingIntent pi = link(c, "ascend://resume");
        rv.setOnClickPendingIntent(R.id.root, pi);
        rv.setOnClickPendingIntent(R.id.r_btn, pi);
        return rv;
    }

    /* ---------- Target (2x2) ---------- */

    static RemoteViews target(Context c, JSONObject s) {
        P p = pal(s);
        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.w_target);
        rv.setInt(R.id.root, "setBackgroundResource", p.cardBg);
        rv.setOnClickPendingIntent(R.id.root, link(c, "ascend://tracker"));
        JSONObject ex = s == null ? null : s.optJSONObject("exam");
        JSONObject f = s == null ? null : s.optJSONObject("focus");
        int st = f == null ? 0 : f.optInt("st");
        if (ex == null) {
            txt(rv, R.id.g_label, "Target", p.sec);
            txt(rv, R.id.g_days, "–", p.text);
            txt(rv, R.id.g_sub, "Set a date in Plan", p.sec);
        } else {
            txt(rv, R.id.g_label, clip(ex.optString("n", "Target"), 18), p.sec);
            txt(rv, R.id.g_days, String.valueOf(ex.optInt("days")), p.text);
            int d = ex.optInt("days");
            String sub = (d == 1 ? "day to go" : "days to go") + (st > 0 ? " · " + st + "d streak" : "");
            txt(rv, R.id.g_sub, sub, p.sec);
        }
        double[] v = new double[7];
        StringBuilder letters = new StringBuilder();
        JSONArray wk = f == null ? null : f.optJSONArray("wk");
        JSONArray dw = f == null ? null : f.optJSONArray("dw");
        String names = "SMTWTFS";
        for (int i = 0; i < 7; i++) {
            v[i] = wk == null ? 0 : wk.optDouble(i, 0);
            int d = dw == null ? i : dw.optInt(i, i);
            letters.append(names.charAt(((d % 7) + 7) % 7));
        }
        rv.setImageViewBitmap(R.id.g_bars, bars(c, 120, 50, v, letters.toString(), p));
        return rv;
    }

    /* ---------- Revise next (4x2) ---------- */

    static RemoteViews revise(Context c, JSONObject s) {
        P p = pal(s);
        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.w_revise);
        rv.setInt(R.id.root, "setBackgroundResource", p.cardBg);
        rv.setInt(R.id.v_btn, "setBackgroundResource", p.accentBg);
        rv.setTextColor(R.id.v_btn, p.onAccent);
        PendingIntent rev = link(c, "ascend://revision");
        rv.setOnClickPendingIntent(R.id.root, rev);
        rv.setOnClickPendingIntent(R.id.v_btn, rev);
        txt(rv, R.id.v_label, "Revise next", p.sec);
        show(rv, R.id.v_c1, false);
        show(rv, R.id.v_c2, false);
        show(rv, R.id.v_c3, false);
        JSONObject r = s == null ? null : s.optJSONObject("rev");
        JSONObject top = r == null ? null : r.optJSONObject("top");
        if (top == null) {
            txt(rv, R.id.v_title, s == null ? "Open Ascend to set up" : "All caught up", p.text);
            txt(rv, R.id.v_sub, s == null ? "" : "Nothing needs revising", p.sec);
        } else {
            txt(rv, R.id.v_title, clip(top.optString("c"), 26), p.text);
            txt(rv, R.id.v_sub, clip(top.optString("s"), 26), p.sec);
            int y = top.optInt("y"), w = top.optInt("w");
            if (y > 0) {
                rv.setInt(R.id.v_c1, "setBackgroundResource", p.chipBg);
                txt(rv, R.id.v_c1, y + " not revised", p.text);
                show(rv, R.id.v_c1, true);
            }
            if (w > 0) {
                rv.setInt(R.id.v_c2, "setBackgroundResource", p.chipBg);
                txt(rv, R.id.v_c2, w + " wrong", p.red);
                show(rv, R.id.v_c2, true);
            }
        }
        JSONObject m = s == null ? null : s.optJSONObject("mist");
        int mw = m == null ? 0 : m.optInt("w"), ms = m == null ? 0 : m.optInt("s");
        if (mw + ms > 0) {
            rv.setInt(R.id.v_c3, "setBackgroundResource", p.chipBg);
            txt(rv, R.id.v_c3, "Mistakes: " + mw + " wrong, " + ms + " skipped", p.text);
            rv.setOnClickPendingIntent(R.id.v_c3, link(c, "ascend://mistakes"));
            show(rv, R.id.v_c3, true);
        }
        return rv;
    }
}
