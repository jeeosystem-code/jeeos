package com.ascend.study;
import android.content.Context;
import android.widget.RemoteViews;
import org.json.JSONObject;
public class WTest extends WBase {
  int layout(){return R.layout.wg_test;}
  String route(JSONObject d){return WG.routeTest(d);}
  void fill(Context c, RemoteViews v, JSONObject d) throws Exception {WG.fillTest(c,v,d);}
}
