package com.ascend.study;
import android.content.Context;
import android.widget.RemoteViews;
import org.json.JSONObject;
public class WMistakes extends WBase {
  int layout(){return R.layout.wg_mistakes;}
  String route(JSONObject d){return WG.routeMistakes(d);}
  void fill(Context c, RemoteViews v, JSONObject d) throws Exception {WG.fillMistakes(c,v,d);}
}
