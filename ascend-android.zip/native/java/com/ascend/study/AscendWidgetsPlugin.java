package com.ascend.study;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
@CapacitorPlugin(name = "AscendWidgets")
public class AscendWidgetsPlugin extends Plugin {
  @PluginMethod
  public void save(PluginCall call) {
    String j = call.getString("json");
    if (j != null) {
      getContext().getSharedPreferences("ascend_wg", 0).edit().putString("json", j).apply();
      WG.refreshAll(getContext());
    }
    call.resolve();
  }
}
