package com.ascend.study;
import android.content.Context;
import android.widget.RemoteViews;
import org.json.JSONObject;
public class WResume extends WBase {
  int layout(){return R.layout.wg_resume;}
  String route(JSONObject d){return WG.routeResume(d);}
  void fill(Context c, RemoteViews v, JSONObject d) throws Exception {WG.fillResume(c,v,d);}
}
