package com.ascend.study;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.SystemClock;
import android.view.View;
import android.widget.RemoteViews;
import androidx.core.content.ContextCompat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;

/** Reads the summary the app saves and fills each widget. Everything here is defensive: a bad value must never crash a widget. */
public class WG {
  static final Class<?>[] ALL = {WToday.class, WFocus.class, WResume.class, WCountdown.class, WWeek.class,
      WMistakes.class, WTest.class, WRevision.class, WHomework.class, WShortcuts.class};

  static JSONObject load(Context c) {
    try {
      String s = c.getSharedPreferences("ascend_wg", 0).getString("json", null);
      return s == null ? null : new JSONObject(s);
    } catch (Exception e) { return null; }
  }

  static void refreshAll(Context c) {
    AppWidgetManager m = AppWidgetManager.getInstance(c);
    for (Class<?> k : ALL) {
      int[] ids = m.getAppWidgetIds(new ComponentName(c, k));
      if (ids == null || ids.length == 0) continue;
      Intent i = new Intent(c, k);
      i.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
      i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids);
      c.sendBroadcast(i);
    }
  }

  static PendingIntent tap(Context c, String uri) {
    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
    i.setPackage(c.getPackageName());
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
    int f = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
    return PendingIntent.getActivity(c, uri.hashCode(), i, f);
  }

  static int col(Context c, int id) { return ContextCompat.getColor(c, id); }
  static String ymd() { return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()); }
  static long dayStart(String ymd) throws Exception { return new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(ymd).getTime(); }
  static int daysTo(String ymd) {
    try {
      Calendar t = Calendar.getInstance();
      t.set(Calendar.HOUR_OF_DAY, 0); t.set(Calendar.MINUTE, 0); t.set(Calendar.SECOND, 0); t.set(Calendar.MILLISECOND, 0);
      return (int) Math.round((dayStart(ymd) - t.getTimeInMillis()) / 86400000.0);
    } catch (Exception e) { return 0; }
  }
  static String nice(String ymd) {
    try { return new SimpleDateFormat("d MMM", Locale.getDefault()).format(new Date(dayStart(ymd))); } catch (Exception e) { return ymd; }
  }
  static String hm(long min) { return min >= 60 ? (min / 60) + "h " + (min % 60) + "m" : min + "m"; }
  static JSONObject o(JSONObject d, String k) { try { return d == null ? null : d.optJSONObject(k); } catch (Exception e) { return null; } }

  // ----- drawing -----
  static Bitmap ring(Context c, double frac, String text, int px, int color) {
    Bitmap b = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888);
    Canvas cv = new Canvas(b);
    float sw = px * 0.13f; RectF r = new RectF(sw / 2, sw / 2, px - sw / 2, px - sw / 2);
    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(sw); p.setStrokeCap(Paint.Cap.ROUND);
    p.setColor(col(c, R.color.wg_track)); cv.drawArc(r, 0, 360, false, p);
    if (frac > 0) { p.setColor(color); cv.drawArc(r, -90, (float) (360 * Math.min(1, frac)), false, p); }
    Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
    t.setColor(col(c, R.color.wg_t)); t.setTextAlign(Paint.Align.CENTER); t.setTypeface(Typeface.DEFAULT_BOLD);
    t.setTextSize(px * (text.length() > 4 ? 0.2f : 0.26f));
    cv.drawText(text, px / 2f, px / 2f + t.getTextSize() * 0.35f, t);
    return b;
  }

  static Bitmap bars(Context c, int[] v, int[] dow) {
    int W = 560, H = 200, bw = 56, gap = 24, x0 = 12, top = 6, base = 164;
    Bitmap b = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
    Canvas cv = new Canvas(b);
    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    int mx = 1; for (int x : v) mx = Math.max(mx, x);
    Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
    t.setColor(col(c, R.color.wg_m)); t.setTextAlign(Paint.Align.CENTER); t.setTextSize(24);
    String L = "SMTWTFS";
    for (int i = 0; i < 7; i++) {
      float x = x0 + i * (bw + gap);
      int h = v[i] <= 0 ? 8 : Math.max(14, (int) ((base - top) * (v[i] / (float) mx)));
      p.setColor(v[i] <= 0 ? col(c, R.color.wg_track) : col(c, R.color.wg_ac));
      p.setAlpha(v[i] <= 0 ? p.getAlpha() : (i == 6 ? 255 : 190));
      cv.drawRoundRect(new RectF(x, base - h, x + bw, base), 12, 12, p);
      cv.drawText(String.valueOf(L.charAt(((dow[i] % 7) + 7) % 7)), x + bw / 2f, H - 8, t);
    }
    return b;
  }

  static String noun(int n, String one, String many) { return n == 1 ? one : many; }

  // ----- Today -----
  static String routeToday(JSONObject d) { return "ascend://today"; }
  static void fillToday(Context c, RemoteViews v, JSONObject d) throws Exception {
    v.setTextViewText(R.id.lb, "Today");
    String msg = null; JSONObject t = o(d, "today");
    if (t == null) msg = "Open Ascend to start";
    else if (!ymd().equals(d.optString("d"))) msg = "Open Ascend to refresh";
    else if (t.optInt("n") == 0) msg = "Nothing planned today";
    else if (t.optJSONArray("items") == null || t.optJSONArray("items").length() == 0) msg = "All done today";
    v.setTextViewText(R.id.rt, t != null && msg == null ? t.optInt("dn") + " of " + t.optInt("n") + " done" : "");
    v.setViewVisibility(R.id.empty, msg == null ? View.GONE : View.VISIBLE);
    if (msg != null) v.setTextViewText(R.id.empty, msg);
    int[] R_ = {R.id.r0, R.id.r1, R.id.r2, R.id.r3}, B = {R.id.b0, R.id.b1, R.id.b2, R.id.b3},
        T = {R.id.t0, R.id.t1, R.id.t2, R.id.t3}, M = {R.id.m0, R.id.m1, R.id.m2, R.id.m3};
    JSONArray a = msg == null ? t.optJSONArray("items") : null;
    for (int i = 0; i < 4; i++) {
      JSONObject it = a != null && i < a.length() ? a.optJSONObject(i) : null;
      v.setViewVisibility(R_[i], it == null ? View.INVISIBLE : View.VISIBLE);
      if (it == null) continue;
      int cl; try { cl = Color.parseColor(it.optString("c", "#0a84ff")); } catch (Exception e) { cl = col(c, R.color.wg_ac); }
      v.setInt(B[i], "setColorFilter", cl);
      v.setTextViewText(T[i], it.optString("t"));
      v.setTextViewText(M[i], it.optString("tm"));
    }
  }

  // ----- Focus -----
  static String routeFocus(JSONObject d) {
    JSONObject f = o(d, "focus");
    return f != null && f.optBoolean("on") ? "ascend://focus" : "ascend://focus?start=1";
  }
  static void fillFocus(Context c, RemoteViews v, JSONObject d) throws Exception {
    JSONObject f = o(d, "focus");
    boolean on = f != null && f.optBoolean("on"), run = on && f.optBoolean("run");
    long end = on ? f.optLong("end") : 0, left = run ? end - System.currentTimeMillis() : (on ? f.optLong("left") : 0);
    v.setViewVisibility(R.id.chr, View.GONE); v.setViewVisibility(R.id.big, View.VISIBLE);
    String ph = on ? f.optString("ph") : "idle";
    String name = "focus".equals(ph) ? "Focus" : ("long".equals(ph) ? "Long break" : "Break");
    if (!on) {
      int fm = f == null ? 25 : f.optInt("f", 25);
      v.setTextViewText(R.id.lb, "Focus");
      v.setTextViewText(R.id.big, fm + " min");
      long tm = f == null ? 0 : f.optLong("tm");
      v.setTextViewText(R.id.sb, tm > 0 ? hm(tm) + " today" : "Ready when you are");
      v.setTextViewText(R.id.btn, "Start");
    } else if (run && left > 0) {
      v.setTextViewText(R.id.lb, name + " · running");
      if (Build.VERSION.SDK_INT >= 24) {
        v.setViewVisibility(R.id.big, View.GONE); v.setViewVisibility(R.id.chr, View.VISIBLE);
        v.setChronometerCountDown(R.id.chr, true);
        v.setChronometer(R.id.chr, SystemClock.elapsedRealtime() + left, null, true);
      } else v.setTextViewText(R.id.big, (left / 60000 + 1) + " min");
      v.setTextViewText(R.id.sb, "focus".equals(ph) ? "Block " + (f.optInt("n") + 1) + " of " + f.optInt("e", 4) : "Take it easy");
      v.setTextViewText(R.id.btn, "Open");
    } else if (run) {
      v.setTextViewText(R.id.lb, name);
      v.setTextViewText(R.id.big, "Done");
      v.setTextViewText(R.id.sb, "Open Ascend to continue");
      v.setTextViewText(R.id.btn, "Open");
    } else {
      long s = Math.max(0, left) / 1000;
      v.setTextViewText(R.id.lb, name + " · paused");
      v.setTextViewText(R.id.big, String.format(Locale.US, "%02d:%02d", s / 60, s % 60));
      v.setTextViewText(R.id.sb, "focus".equals(ph) ? "Block " + (f.optInt("n") + 1) + " of " + f.optInt("e", 4) : "Paused");
      v.setTextViewText(R.id.btn, "Resume");
    }
  }

  // ----- Resume -----
  static String routeResume(JSONObject d) { return o(d, "resume") != null ? "ascend://resume" : "ascend://today"; }
  static void fillResume(Context c, RemoteViews v, JSONObject d) throws Exception {
    JSONObject r = o(d, "resume");
    v.setTextViewText(R.id.lb, r == null ? "Resume" : "Resume · " + r.optString("k"));
    if (r == null) {
      v.setImageViewBitmap(R.id.ring, ring(c, 0, "–", 120, col(c, R.color.wg_ac)));
      v.setTextViewText(R.id.nm, "No unfinished session");
      v.setTextViewText(R.id.rt, "");
    } else {
      int dn = r.optInt("dn"), t = Math.max(1, r.optInt("t"));
      v.setImageViewBitmap(R.id.ring, ring(c, dn / (double) t, dn + "/" + t, 120, col(c, R.color.wg_ac)));
      v.setTextViewText(R.id.nm, r.optString("n"));
      v.setTextViewText(R.id.rt, "Tap to resume");
    }
  }

  // ----- Countdown -----
  static String routeCountdown(JSONObject d) { return "ascend://today"; }
  static void fillCountdown(Context c, RemoteViews v, JSONObject d) throws Exception {
    JSONObject e = o(d, "exam");
    v.setTextViewText(R.id.lb, "Countdown");
    if (e == null) { v.setTextViewText(R.id.big, "–"); v.setTextViewText(R.id.sb, "Set a target in Planner"); return; }
    int n = daysTo(e.optString("d"));
    if (n < 0) { v.setTextViewText(R.id.big, "Done"); v.setTextViewText(R.id.sb, e.optString("n")); }
    else if (n == 0) { v.setTextViewText(R.id.big, "Today"); v.setTextViewText(R.id.sb, e.optString("n")); }
    else { v.setTextViewText(R.id.big, String.valueOf(n)); v.setTextViewText(R.id.sb, noun(n, "day", "days") + " to " + e.optString("n")); }
  }

  // ----- Focus week -----
  static String routeWeek(JSONObject d) { return "ascend://week"; }
  static void fillWeek(Context c, RemoteViews v, JSONObject d) throws Exception {
    JSONObject f = o(d, "focus");
    int[] w = new int[7], dw = {1, 2, 3, 4, 5, 6, 0};
    if (f != null) {
      JSONArray a = f.optJSONArray("wk"), b = f.optJSONArray("dw");
      for (int i = 0; i < 7; i++) { if (a != null) w[i] = a.optInt(i); if (b != null) dw[i] = b.optInt(i); }
    }
    int st = f == null ? 0 : f.optInt("st");
    v.setTextViewText(R.id.lb, "Focus week");
    v.setTextViewText(R.id.rt, st > 0 ? st + "-day streak" : "Start a streak today");
    v.setImageViewBitmap(R.id.bars, bars(c, w, dw));
  }

  // ----- Mistakes -----
  static String routeMistakes(JSONObject d) { return "ascend://mistakes"; }
  static void fillMistakes(Context c, RemoteViews v, JSONObject d) throws Exception {
    JSONObject m = o(d, "mist");
    int w = m == null ? 0 : m.optInt("w"), s = m == null ? 0 : m.optInt("s");
    v.setTextViewText(R.id.lb, "Mistakes");
    v.setTextViewText(R.id.big, String.valueOf(w + s));
    v.setTextViewText(R.id.sb, w + s == 0 ? "All clear" : noun(w + s, "open mistake", "open mistakes"));
    v.setTextViewText(R.id.cw, w + " wrong");
    v.setTextViewText(R.id.cs, s + " skip");
  }

  // ----- Next test -----
  static String routeTest(JSONObject d) {
    JSONObject t = o(d, "test");
    if (t == null || t.optString("id").length() == 0) return "ascend://log";
    return "ascend://test?id=" + Uri.encode(t.optString("id"));
  }
  static void fillTest(Context c, RemoteViews v, JSONObject d) throws Exception {
    JSONObject t = o(d, "test");
    if (t == null) {
      v.setTextViewText(R.id.lb, "Next test"); v.setTextViewText(R.id.rt, "");
      v.setTextViewText(R.id.nm, "No test planned"); v.setTextViewText(R.id.sb, "Add one in Tests");
      return;
    }
    int tg = t.optInt("tg");
    if (t.optInt("up") == 1) {
      int n = daysTo(t.optString("d"));
      v.setTextViewText(R.id.lb, "Next test");
      v.setTextViewText(R.id.rt, n <= 0 ? "Today" : "in " + n + " " + noun(n, "day", "days"));
      v.setTextViewText(R.id.nm, t.optString("n"));
      v.setTextViewText(R.id.sb, nice(t.optString("d")) + (tg > 0 ? " · target " + tg : ""));
    } else {
      v.setTextViewText(R.id.lb, "Latest score");
      v.setTextViewText(R.id.rt, nice(t.optString("d")));
      v.setTextViewText(R.id.nm, t.optString("n"));
      v.setTextViewText(R.id.sb, "Scored " + t.optInt("sc") + " / " + t.optInt("mx") + (tg > 0 ? " · target " + tg : ""));
    }
  }

  // ----- Revision due -----
  static String routeRevision(JSONObject d) { return "ascend://revision"; }
  static void fillRevision(Context c, RemoteViews v, JSONObject d) throws Exception {
    JSONObject r = o(d, "rev");
    int n = r == null ? 0 : r.optInt("n");
    v.setTextViewText(R.id.lb, "Revision due");
    v.setTextViewText(R.id.big, String.valueOf(n));
    v.setTextViewText(R.id.sb, noun(n, "chapter", "chapters"));
    JSONObject top = r == null ? null : r.optJSONObject("top");
    v.setTextViewText(R.id.top, top != null ? top.optString("c") : "All caught up");
  }

  // ----- Homework -----
  static String routeHomework(JSONObject d) { return "ascend://homework"; }
  static void fillHomework(Context c, RemoteViews v, JSONObject d) throws Exception {
    JSONObject h = o(d, "hw");
    int dn = h == null ? 0 : h.optInt("dn"), t = h == null ? 0 : h.optInt("t"), od = h == null ? 0 : h.optInt("od");
    v.setTextViewText(R.id.lb, "Homework");
    v.setImageViewBitmap(R.id.ring, ring(c, t == 0 ? 0 : dn / (double) t, t == 0 ? "–" : dn + "/" + t, 150, col(c, R.color.wg_ac)));
    v.setTextViewText(R.id.sb, t == 0 ? "Nothing set this week" : "this week");
    v.setTextViewText(R.id.od, od > 0 ? od + " overdue" : "");
  }

  // ----- Shortcuts -----
  static String routeShortcuts(JSONObject d) { return "ascend://today"; }
  static void fillShortcuts(Context c, RemoteViews v, JSONObject d) throws Exception {
    v.setOnClickPendingIntent(R.id.s1, tap(c, "ascend://add"));
    v.setOnClickPendingIntent(R.id.s2, tap(c, "ascend://focus?start=1"));
    v.setOnClickPendingIntent(R.id.s3, tap(c, "ascend://log"));
    v.setOnClickPendingIntent(R.id.s4, tap(c, "ascend://practice"));
  }
}
