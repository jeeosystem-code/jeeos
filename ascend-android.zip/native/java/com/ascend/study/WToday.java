package com.ascend.study;
import android.content.Context;
import android.widget.RemoteViews;
import org.json.JSONObject;
public class WToday extends WBase {
  int layout(){return R.layout.wg_today;}
  String route(JSONObject d){return WG.routeToday(d);}
  void fill(Context c, RemoteViews v, JSONObject d) throws Exception {WG.fillToday(c,v,d);}
}
