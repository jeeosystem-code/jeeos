package com.ascend.study;
import android.content.Context;
import android.widget.RemoteViews;
import org.json.JSONObject;
public class WWeek extends WBase {
  int layout(){return R.layout.wg_week;}
  String route(JSONObject d){return WG.routeWeek(d);}
  void fill(Context c, RemoteViews v, JSONObject d) throws Exception {WG.fillWeek(c,v,d);}
}
