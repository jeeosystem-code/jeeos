package com.ascend.study;
import android.content.Context;
import android.widget.RemoteViews;
import org.json.JSONObject;
public class WFocus extends WBase {
  int layout(){return R.layout.wg_focus;}
  String route(JSONObject d){return WG.routeFocus(d);}
  void fill(Context c, RemoteViews v, JSONObject d) throws Exception {WG.fillFocus(c,v,d);}
}
