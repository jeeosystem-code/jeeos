package com.ascend.study;
import android.os.Bundle;
import com.getcapacitor.BridgeActivity;
public class MainActivity extends BridgeActivity {
  @Override public void onCreate(Bundle savedInstanceState) {
    registerPlugin(AscendWidgetsPlugin.class);
    super.onCreate(savedInstanceState);
  }
}
