package com.ascend.study;
import android.content.Context;
import android.widget.RemoteViews;
import org.json.JSONObject;
public class WRevision extends WBase {
  int layout(){return R.layout.wg_revision;}
  String route(JSONObject d){return WG.routeRevision(d);}
  void fill(Context c, RemoteViews v, JSONObject d) throws Exception {WG.fillRevision(c,v,d);}
}
