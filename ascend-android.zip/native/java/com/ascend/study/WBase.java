package com.ascend.study;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.widget.RemoteViews;
import org.json.JSONObject;
public abstract class WBase extends AppWidgetProvider {
  abstract int layout();
  abstract String route(JSONObject d);
  abstract void fill(Context c, RemoteViews v, JSONObject d) throws Exception;
  @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
    for (int id : ids) m.updateAppWidget(id, make(c));
  }
  RemoteViews make(Context c) {
    RemoteViews v = new RemoteViews(c.getPackageName(), layout());
    JSONObject d = WG.load(c);
    try { fill(c, v, d); } catch (Exception e) { }
    v.setOnClickPendingIntent(R.id.root, WG.tap(c, route(d)));
    return v;
  }
}
