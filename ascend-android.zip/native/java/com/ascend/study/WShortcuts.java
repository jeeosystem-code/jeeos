package com.ascend.study;
import android.content.Context;
import android.widget.RemoteViews;
import org.json.JSONObject;
public class WShortcuts extends WBase {
  int layout(){return R.layout.wg_shortcuts;}
  String route(JSONObject d){return WG.routeShortcuts(d);}
  void fill(Context c, RemoteViews v, JSONObject d) throws Exception {WG.fillShortcuts(c,v,d);}
}
