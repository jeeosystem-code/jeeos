package com.ascend.study;
import android.content.Context;
import android.widget.RemoteViews;
import org.json.JSONObject;
public class WCountdown extends WBase {
  int layout(){return R.layout.wg_countdown;}
  String route(JSONObject d){return WG.routeCountdown(d);}
  void fill(Context c, RemoteViews v, JSONObject d) throws Exception {WG.fillCountdown(c,v,d);}
}
