package com.ascend.study;
import android.content.Context;
import android.widget.RemoteViews;
import org.json.JSONObject;
public class WHomework extends WBase {
  int layout(){return R.layout.wg_homework;}
  String route(JSONObject d){return WG.routeHomework(d);}
  void fill(Context c, RemoteViews v, JSONObject d) throws Exception {WG.fillHomework(c,v,d);}
}
