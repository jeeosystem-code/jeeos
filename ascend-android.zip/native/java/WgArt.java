package com.ascend.study;

import android.app.PendingIntent;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Build;
import android.os.SystemClock;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Draws each widget as one picture with Ascend's own fonts, so the phone's default font never shows and
 * nothing can overlap. Only the running countdown stays a live text view, placed inside its ring.
 */
public class WgArt {
    final Context c;
    final Bitmap bm;
    final Canvas cv;
    final float d;      /* pixels per dp */
    final float W, H;   /* size in dp */
    final Wg.P p;
    final Typeface lexB, lexR, sora, unb;
    final Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG);
    final int a1, a2;   /* accent gradient ends */
    Bitmap logo;

    WgArt(Context c, Wg.P p, int wDp, int hDp) {
        this.c = c;
        this.p = p;
        float dens = c.getResources().getDisplayMetrics().density;
        float s = dens;
        float maxPx = 1000f;
        if (wDp * s > maxPx) s = maxPx / wDp;
        d = s;
        W = wDp;
        H = hDp;
        bm = Bitmap.createBitmap(Math.max(1, Math.round(wDp * d)), Math.max(1, Math.round(hDp * d)), Bitmap.Config.ARGB_8888);
        cv = new Canvas(bm);
        lexB = Wg.font(c, R.font.lexend_bold);
        lexR = Wg.font(c, R.font.lexend_regular);
        sora = Wg.font(c, R.font.sora_bold);
        unb = Wg.font(c, R.font.unbounded_bold);
        a1 = p.dark ? 0xFF74BDFF : 0xFF4AA3FF;
        a2 = p.dark ? 0xFF8E8CFF : 0xFF5E5CE6;
    }

    /* ---------- drawing helpers (all positions in dp) ---------- */

    Paint fill(int color) {
        pt.reset();
        pt.setAntiAlias(true);
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(color);
        return pt;
    }

    void rr(float x, float y, float w, float h, float r, int color) {
        cv.drawRoundRect(new RectF(x * d, y * d, (x + w) * d, (y + h) * d), r * d, r * d, fill(color));
    }

    void grad(float x, float y, float w, float h, float r, int c1, int c2) {
        Paint g = fill(0xFFFFFFFF);
        g.setShader(new LinearGradient(x * d, y * d, (x + w) * d, (y + h) * d, c1, c2, Shader.TileMode.CLAMP));
        cv.drawRoundRect(new RectF(x * d, y * d, (x + w) * d, (y + h) * d), r * d, r * d, g);
    }

    void line(float x, float y, float w, float h, float r, int color, float stroke) {
        pt.reset();
        pt.setAntiAlias(true);
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(stroke * d);
        pt.setColor(color);
        cv.drawRoundRect(new RectF(x * d, y * d, (x + w) * d, (y + h) * d), r * d, r * d, pt);
    }

    Paint tp(Typeface tf, float sizeDp, int color, Paint.Align al) {
        pt.reset();
        pt.setAntiAlias(true);
        pt.setStyle(Paint.Style.FILL);
        pt.setTypeface(tf);
        pt.setTextSize(sizeDp * d);
        pt.setColor(color);
        pt.setTextAlign(al);
        return pt;
    }

    float tw(String s, Typeface tf, float sizeDp) {
        Paint t = tp(tf, sizeDp, 0, Paint.Align.LEFT);
        return t.measureText(s) / d;
    }

    String fit(String s, Typeface tf, float sizeDp, float maxW) {
        if (s == null) return "";
        if (tw(s, tf, sizeDp) <= maxW) return s;
        String t = s;
        while (t.length() > 1 && tw(t + "…", tf, sizeDp) > maxW) t = t.substring(0, t.length() - 1);
        return t.trim() + "…";
    }

    /** Draws text with its baseline at y. Long text is shortened with an ellipsis so it never runs past maxW. */
    void text(String s, float x, float y, Typeface tf, float sizeDp, int color, Paint.Align al, float maxW) {
        if (s == null || s.length() == 0) return;
        String t = maxW > 0 ? fit(s, tf, sizeDp, maxW) : s;
        cv.drawText(t, x * d, y * d, tp(tf, sizeDp, color, al));
    }

    /** Largest size (down to minDp) at which s fits maxW. */
    float sizeFor(String s, Typeface tf, float startDp, float minDp, float maxW) {
        float z = startDp;
        while (z > minDp && tw(s, tf, z) > maxW) z -= 0.5f;
        return z;
    }

    void caps(String s, float x, float y, float sizeDp, int color, Paint.Align al, float maxW) {
        if (s == null || s.length() == 0) return;
        String t = s.toUpperCase(Locale.US);
        Paint q = tp(lexB, sizeDp, color, al);
        q.setLetterSpacing(0.08f);
        while (t.length() > 1 && maxW > 0 && q.measureText(t) / d > maxW) {
            t = t.substring(0, t.length() - 1);
            if (t.length() > 1) t = t.trim();
        }
        cv.drawText(t, x * d, y * d, q);
    }

    void card() {
        float r = 24;
        Path clip = new Path();
        clip.addRoundRect(new RectF(0, 0, W * d, H * d), r * d, r * d, Path.Direction.CW);
        cv.save();
        cv.clipPath(clip);
        Paint g = fill(0xFFFFFFFF);
        int top = p.dark ? 0xFF1B2040 : 0xFFFFFFFF;
        int bot = p.dark ? 0xFF0F1225 : 0xFFEEF2FC;
        g.setShader(new LinearGradient(0, 0, 0, H * d, top, bot, Shader.TileMode.CLAMP));
        cv.drawRect(0, 0, W * d, H * d, g);
        Paint g1 = fill(0xFFFFFFFF);
        g1.setShader(new RadialGradient(W * 0.96f * d, -H * 0.05f * d, Math.max(W, H) * 0.75f * d,
            p.dark ? 0x408E8CFF : 0x335E5CE6, 0x005E5CE6, Shader.TileMode.CLAMP));
        cv.drawRect(0, 0, W * d, H * d, g1);
        Paint g2 = fill(0xFFFFFFFF);
        g2.setShader(new RadialGradient(-W * 0.05f * d, H * 1.05f * d, Math.max(W, H) * 0.6f * d,
            p.dark ? 0x2674BDFF : 0x224AA3FF, 0x004AA3FF, Shader.TileMode.CLAMP));
        cv.drawRect(0, 0, W * d, H * d, g2);
        cv.restore();
        line(0.5f, 0.5f, W - 1, H - 1, r, p.dark ? 0x22FFFFFF : 0x1F5E5CE6, 1f);
    }

    void mark(float x, float y, float s) {
        if (logo == null) {
            try { logo = android.graphics.BitmapFactory.decodeResource(c.getResources(), R.drawable.w_logo); } catch (Throwable e) { logo = null; }
        }
        if (logo != null) {
            Paint lp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
            cv.drawBitmap(logo, null, new RectF(x * d, y * d, (x + s) * d, (y + s) * d), lp);
        } else {
            grad(x, y, s, s, s * 0.3f, a1, a2);
        }
    }

    void pillBtn(String label, float x, float y, float w, float h) {
        grad(x, y, w, h, h / 2, a1, a2);
        float z = sizeFor(label, lexB, 13, 9, w - 16);
        text(label, x + w / 2, y + h / 2 + z * 0.36f, lexB, z, p.dark ? 0xFF10122A : 0xFFFFFFFF, Paint.Align.CENTER, 0);
    }

    void ring(float cx, float cy, float diam, float frac, boolean green, boolean dim) {
        float sw = diam * 0.115f;
        float rad = (diam - sw) / 2f;
        RectF r = new RectF((cx - rad) * d, (cy - rad) * d, (cx + rad) * d, (cy + rad) * d);
        pt.reset();
        pt.setAntiAlias(true);
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(sw * d);
        pt.setColor(p.track);
        cv.drawArc(r, 0, 360, false, pt);
        if (frac > 0) {
            pt.setStrokeCap(Paint.Cap.ROUND);
            int g1 = green ? (p.dark ? 0xFF7FD0A0 : 0xFF3DBE7D) : a1;
            int g2 = green ? (p.dark ? 0xFF4FB58A : 0xFF2F8F5B) : a2;
            if (dim) { g1 = p.sec; g2 = p.sec; }
            pt.setShader(new LinearGradient((cx - rad) * d, (cy + rad) * d, (cx + rad) * d, (cy - rad) * d, g1, g2, Shader.TileMode.CLAMP));
            cv.drawArc(r, -90, 360f * Math.min(1f, frac), false, pt);
        }
    }

    void bar(float x, float y, float w, float h, float frac) {
        rr(x, y, w, h, h / 2, p.track);
        if (frac > 0) grad(x, y, Math.max(h, w * Math.min(1f, frac)), h, h / 2, a1, a2);
    }

    void chip(float x, float y, String s, int color, float h) {
        float w = tw(s, lexR, 11.5f) + 20;
        rr(x, y, w, h, h / 2, p.dark ? 0xFF232A44 : 0xFFE9EDFA);
        text(s, x + 10, y + h / 2 + 4.1f, lexR, 11.5f, color, Paint.Align.LEFT, 0);
    }

    void playGlyph(float cx, float cy, boolean pause, int color) {
        Paint f = fill(color);
        if (pause) {
            cv.drawRoundRect(new RectF((cx - 6) * d, (cy - 7) * d, (cx - 2) * d, (cy + 7) * d), d, d, f);
            cv.drawRoundRect(new RectF((cx + 2) * d, (cy - 7) * d, (cx + 6) * d, (cy + 7) * d), d, d, f);
        } else {
            Path t = new Path();
            t.moveTo((cx - 4) * d, (cy - 8) * d);
            t.lineTo((cx + 8) * d, cy * d);
            t.lineTo((cx - 4) * d, (cy + 8) * d);
            t.close();
            cv.drawPath(t, f);
        }
    }

    List<String> wrap(String s, Typeface tf, float sizeDp, float maxW, int maxLines) {
        List<String> out = new ArrayList<String>();
        String[] words = s.split(" ");
        String cur = "";
        for (int i = 0; i < words.length; i++) {
            String tryS = cur.length() == 0 ? words[i] : cur + " " + words[i];
            if (tw(tryS, tf, sizeDp) <= maxW || cur.length() == 0) {
                cur = tryS;
            } else {
                out.add(cur);
                cur = words[i];
                if (out.size() == maxLines - 1) {
                    StringBuilder rest = new StringBuilder(cur);
                    for (int j = i + 1; j < words.length; j++) rest.append(' ').append(words[j]);
                    cur = rest.toString();
                    break;
                }
            }
        }
        if (cur.length() > 0) out.add(fit(cur, tf, sizeDp, maxW));
        return out;
    }

    /* ---------- the widgets ---------- */

    static boolean fresh(JSONObject s) {
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        return s != null && today.equals(s.optString("d"));
    }

    static RemoteViews shell(Context c, int layout, WgArt a, String desc, String uri) {
        RemoteViews rv = new RemoteViews(c.getPackageName(), layout);
        rv.setImageViewBitmap(R.id.art, a.bm);
        rv.setContentDescription(R.id.art, desc);
        rv.setOnClickPendingIntent(R.id.root, Wg.link(c, uri));
        return rv;
    }

    static RemoteViews make(Context c, JSONObject s, Class<?> kind, int w, int h) {
        Wg.P p = Wg.pal(s);
        if (kind == TodayWidget.class) return today(c, s, p, w > 0 ? w : 320, h > 0 ? h : 150);
        if (kind == RingWidget.class) return dayRing(c, s, p, w > 0 ? w : 150, h > 0 ? h : 150);
        if (kind == FocusWidget.class) return focus(c, s, p, w > 0 ? w : 150, h > 0 ? h : 150);
        if (kind == FocusWideWidget.class) return focusWide(c, s, p, w > 0 ? w : 320, h > 0 ? h : 150);
        if (kind == PracticeWidget.class) return practice(c, s, p, w > 0 ? w : 320, h > 0 ? h : 150);
        if (kind == ResumeWidget.class) return resume(c, s, p, w > 0 ? w : 320, h > 0 ? h : 72);
        if (kind == TargetWidget.class) return target(c, s, p, w > 0 ? w : 150, h > 0 ? h : 150);
        return revise(c, s, p, w > 0 ? w : 320, h > 0 ? h : 150);
    }

    /* Today */
    static RemoteViews today(Context c, JSONObject s, Wg.P p, int w, int h) {
        WgArt a = new WgArt(c, p, w, h);
        a.card();
        a.mark(16, 14, 22);
        a.text("Today", 46, 31, a.lexB, 18, p.text, Paint.Align.LEFT, 0);
        float tx = 46 + a.tw("Today", a.lexB, 18) + 8;
        JSONObject td = s == null ? null : s.optJSONObject("today");
        String desc = "Today";
        if (td == null || !fresh(s)) {
            a.text(td == null ? "Open Ascend to set up" : "Open Ascend to refresh", w / 2f, h / 2f + 14, a.lexR, 14, p.sec, Paint.Align.CENTER, w - 40);
            a.bar(16, 44, w - 32, 6, 0f);
            return shell(c, R.layout.w_art, a, desc, "ascend://today");
        }
        int n = td.optInt("n"), dn = td.optInt("dn"), od = td.optInt("od"), tm = td.optInt("tm");
        float rightW = 0;
        if (tm > 0) {
            String t = Wg.hm(tm);
            float pw = a.tw(t, a.sora, 11) + 22;
            a.rr(w - 16 - pw, 13, pw, 24, 12, p.dark ? 0xFF232A44 : 0xFFE9EDFA);
            a.text(t, w - 16 - pw / 2, 29, a.sora, 11, p.text, Paint.Align.CENTER, 0);
            rightW = pw + 8;
        }
        a.text(n == 0 ? "Nothing planned" : dn + " of " + n + " done", tx, 31, a.lexR, 12, p.sec, Paint.Align.LEFT, w - 16 - rightW - tx);
        a.bar(16, 44, w - 32, 6, n > 0 ? (float) dn / n : 0f);
        JSONArray items = td.optJSONArray("items");
        int cnt = items == null ? 0 : items.length();
        int left = (n - dn) - Math.min(3, cnt);
        float reserve = (od > 0 || left > 0) ? 38 : 10;
        float y0 = 58, rowH = 38;
        int maxRows = (int) Math.floor((h - y0 - reserve) / rowH);
        maxRows = Math.max(1, Math.min(3, maxRows));
        if (cnt == 0) {
            a.text(n == 0 ? "Tap to plan your day" : "All done for today", w / 2f, (y0 + h - reserve) / 2f + 5, a.lexB, 14, n > 0 ? p.green : p.sec, Paint.Align.CENTER, w - 40);
        }
        int shown = Math.min(maxRows, cnt);
        for (int i = 0; i < shown; i++) {
            JSONObject it = items.optJSONObject(i);
            if (it == null) continue;
            float cy = y0 + i * rowH + rowH / 2f;
            a.line(16 + 1, cy - 10.5f + 1, 19, 19, 9.5f, p.dark ? 0xFF4A5275 : 0xFFAAB3CF, 2f);
            String right = it.optString("p");
            if (right.length() == 0) right = it.optString("tm");
            float rw = right.length() == 0 ? 0 : a.tw(right, a.sora, 11) + 8;
            float maxW = w - 52 - 16 - rw;
            a.text(it.optString("t"), 52, cy - 1, a.lexB, 14, p.text, Paint.Align.LEFT, maxW);
            a.text(it.optString("s"), 52, cy + 13, a.lexR, 11, p.sec, Paint.Align.LEFT, maxW);
            a.text(right, w - 16, cy + 4, a.sora, 11, p.sec, Paint.Align.RIGHT, 0);
        }
        int more = (n - dn) - shown;
        if (more > 0) a.text("+" + more + " more", 18, h - 16, a.lexR, 12, p.sec, Paint.Align.LEFT, 90);
        if (od > 0) {
            String t = od + " overdue ›";
            float pw = a.tw(t, a.lexB, 11.5f) + 24;
            a.rr(w - 16 - pw, h - 14 - 26, pw, 26, 13, p.dark ? 0xFF3B2220 : 0xFFFFE4DF);
            a.text(t, w - 16 - pw / 2, h - 14 - 9, a.lexB, 11.5f, p.red, Paint.Align.CENTER, 0);
        }
        return shell(c, R.layout.w_art, a, desc + ", " + dn + " of " + n + " done", "ascend://today");
    }

    /* Day ring 2x2 */
    static RemoteViews dayRing(Context c, JSONObject s, Wg.P p, int w, int h) {
        WgArt a = new WgArt(c, p, w, h);
        a.card();
        a.mark(14, 14, 20);
        a.caps("Today", w - 14, 28, 10, p.sec, Paint.Align.RIGHT, w - 70);
        float diam = Math.min(w - 36, h - 74);
        float cx = w / 2f, cy = 40 + (h - 40 - 30) / 2f;
        JSONObject td = s == null ? null : s.optJSONObject("today");
        boolean ok = td != null && fresh(s);
        int n = ok ? td.optInt("n") : 0, dn = ok ? td.optInt("dn") : 0, od = ok ? td.optInt("od") : 0;
        a.ring(cx, cy, diam, n > 0 ? (float) dn / n : 0f, n > 0 && dn >= n, false);
        String mid = ok ? dn + "/" + n : "–";
        float inner = diam * 0.77f;
        float z = a.sizeFor(mid, a.unb, 22, 9, inner * 0.92f);
        a.text(mid, cx, cy + z * 0.36f, a.unb, z, p.text, Paint.Align.CENTER, 0);
        String cap;
        int col = p.sec;
        if (!ok) cap = "Open Ascend";
        else if (od > 0) { cap = od + " overdue"; col = p.red; }
        else if (n == 0) cap = "Plan your day";
        else if (dn >= n) { cap = "All done"; col = p.green; }
        else cap = "On track";
        a.text(cap, w / 2f, h - 14, a.lexB, 13, col, Paint.Align.CENTER, w - 24);
        return shell(c, R.layout.w_art, a, "Today " + mid, "ascend://today");
    }

    /* Focus 2x2 */
    static RemoteViews focus(Context c, JSONObject s, Wg.P p, int w, int h) {
        WgArt a = new WgArt(c, p, w, h);
        a.card();
        JSONObject f = s == null ? null : s.optJSONObject("focus");
        boolean on = f != null && f.optBoolean("on");
        boolean run = on && f.optBoolean("run");
        String ph = f == null ? "idle" : f.optString("ph", "idle");
        long end = f == null ? 0 : f.optLong("end");
        long left = f == null ? 0 : f.optLong("left");
        int st = f == null ? 0 : f.optInt("st");
        int mins = f == null ? 25 : Math.max(1, f.optInt("f", 25));
        long now = System.currentTimeMillis();
        boolean brk = "short".equals(ph) || "long".equals(ph);
        boolean live = run && end > now && Build.VERSION.SDK_INT >= 24;
        float diam = Math.max(70, Math.min(w - 36, h - 78));
        float cx = w / 2f, cy = h / 2f + 1;
        String head = !on ? "Focus" : (brk ? "Break" : "Focus · block " + Math.max(1, f.optInt("n")) + " of " + Math.max(1, f.optInt("e", 4)));
        a.text(head, w / 2f, 24, a.lexR, 12, p.sec, Paint.Align.CENTER, w - 24);
        String mid = null;
        int midCol = p.text;
        String foot;
        if (!on) {
            a.ring(cx, cy, diam, 0f, false, false);
            mid = "Start";
            midCol = p.dark ? 0xFF8E8CFF : 0xFF5E5CE6;
            foot = st > 0 ? st + " day streak" : mins + " min block";
        } else if (run && end > now) {
            a.ring(cx, cy, diam, 1f, brk, false);
            foot = brk ? "Rest up" : "Keep going";
            if (!live) {
                long sec = (end - now) / 1000;
                mid = String.format(Locale.US, "%d:%02d", sec / 60, sec % 60);
            }
        } else if (run) {
            a.ring(cx, cy, diam, 1f, true, false);
            mid = "Done";
            midCol = p.green;
            foot = "Open to continue";
        } else {
            a.ring(cx, cy, diam, 0.5f, false, true);
            long sec = left / 1000;
            mid = String.format(Locale.US, "%d:%02d", sec / 60, sec % 60);
            foot = "Paused";
        }
        float inner = diam * 0.77f;
        if (mid != null) {
            float z = a.sizeFor(mid, a.sora, "Start".equals(mid) ? 13 : 20, 9, inner * 0.9f);
            a.text(mid, cx, cy + z * 0.36f, a.sora, z, midCol, Paint.Align.CENTER, 0);
        }
        a.text(foot, w / 2f, h - 14, a.lexB, 12, p.sec, Paint.Align.CENTER, w - 24);
        RemoteViews rv = shell(c, R.layout.w_art_f, a, "Focus timer", on ? "ascend://focus" : "ascend://focus?start=1");
        if (live) {
            rv.setViewVisibility(R.id.chrono, android.view.View.VISIBLE);
            long base = SystemClock.elapsedRealtime() + (end - now);
            rv.setChronometerCountDown(R.id.chrono, true);
            rv.setChronometer(R.id.chrono, base, null, true);
            rv.setTextColor(R.id.chrono, p.text);
        }
        return rv;
    }

    /* Focus wide 4x2 */
    static final String[] QUOTES = {
        "Break the mountain into questions.", "Quit the scroll. Keep the streak.",
        "Every block you finish is a vote for your goal.", "Hard now, easy later.",
        "Pressure is proof it matters.", "Keep the phone away and the mind close."
    };

    static RemoteViews focusWide(Context c, JSONObject s, Wg.P p, int w, int h) {
        WgArt a = new WgArt(c, p, w, h);
        a.card();
        JSONObject f = s == null ? null : s.optJSONObject("focus");
        boolean on = f != null && f.optBoolean("on");
        boolean run = on && f.optBoolean("run");
        String ph = f == null ? "idle" : f.optString("ph", "idle");
        long end = f == null ? 0 : f.optLong("end");
        long left = f == null ? 0 : f.optLong("left");
        long now = System.currentTimeMillis();
        boolean brk = "short".equals(ph) || "long".equals(ph);
        boolean live = run && end > now && Build.VERSION.SDK_INT >= 24;
        int fm = f == null ? 25 : Math.max(1, f.optInt("f", 25));
        int sb = f == null ? 5 : Math.max(1, f.optInt("sb", 5));
        int blocks = f == null ? 4 : Math.max(1, f.optInt("e", 4));
        int cur = f == null ? 1 : Math.max(1, f.optInt("n"));
        int day = (int) ((now / 86400000L) % QUOTES.length);
        int todayMin = f == null ? 0 : f.optInt("tm");
        int week = 0;
        JSONArray wk = f == null ? null : f.optJSONArray("wk");
        if (wk != null) for (int i = 0; i < wk.length(); i++) week += wk.optInt(i);

        float diam = 84, cx = 16 + diam / 2f, cy = h / 2f;
        String mid = null;
        int midCol = p.text;
        if (!on) {
            a.ring(cx, cy, diam, 0f, false, false);
            mid = fm + ":00";
        } else if (run && end > now) {
            a.ring(cx, cy, diam, 1f, brk, false);
            if (!live) {
                long sec = (end - now) / 1000;
                mid = String.format(Locale.US, "%d:%02d", sec / 60, sec % 60);
            }
        } else if (run) {
            a.ring(cx, cy, diam, 1f, true, false);
            mid = "Done";
            midCol = p.green;
        } else {
            a.ring(cx, cy, diam, 0.5f, false, true);
            long sec = left / 1000;
            mid = String.format(Locale.US, "%d:%02d", sec / 60, sec % 60);
        }
        if (mid != null) {
            float z = a.sizeFor(mid, a.sora, 18, 9, diam * 0.77f * 0.88f);
            a.text(mid, cx, cy + z * 0.36f, a.sora, z, midCol, Paint.Align.CENTER, 0);
        }
        float x0 = 16 + diam + 18, cw = w - x0 - 16;
        a.mark(x0, 14, 18);
        String eye = fm + " / " + sb + (on ? " · " + (brk ? "break" : "block " + cur + " of " + blocks) : " · ready");
        a.caps(eye, x0 + 26, 27, 10, p.dark ? 0xFF8E8CFF : 0xFF5E5CE6, Paint.Align.LEFT, cw - 26);
        List<String> lines = a.wrap(QUOTES[day], a.lexB, 14.5f, cw, 2);
        for (int i = 0; i < lines.size(); i++) a.text(lines.get(i), x0, 52 + i * 19, a.lexB, 14.5f, p.text, Paint.Align.LEFT, cw);
        String s1 = todayMin > 0 ? Wg.hm(todayMin) : "0m";
        String s2 = week > 0 ? Wg.hm(week) : "0m";
        float by = h - 34;
        a.text(s1, x0, by, a.sora, 14, p.text, Paint.Align.LEFT, 0);
        a.text("Today", x0, by + 14, a.lexR, 10, p.sec, Paint.Align.LEFT, 0);
        float x2 = x0 + Math.max(a.tw(s1, a.sora, 14), 36) + 18;
        a.text(s2, x2, by, a.sora, 14, p.text, Paint.Align.LEFT, 0);
        a.text("This week", x2, by + 14, a.lexR, 10, p.sec, Paint.Align.LEFT, 0);
        float bx = w - 16 - 36;
        a.grad(bx, h - 16 - 36, 36, 36, 18, a.a1, a.a2);
        a.playGlyph(bx + 18, h - 16 - 18, on && run && !brk ? true : (on && run), p.dark ? 0xFF10122A : 0xFFFFFFFF);
        RemoteViews rv = shell(c, R.layout.w_art_fw, a, "Focus timer", on ? "ascend://focus" : "ascend://focus?start=1");
        if (live) {
            rv.setViewVisibility(R.id.chrono, android.view.View.VISIBLE);
            long base = SystemClock.elapsedRealtime() + (end - now);
            rv.setChronometerCountDown(R.id.chrono, true);
            rv.setChronometer(R.id.chrono, base, null, true);
            rv.setTextColor(R.id.chrono, p.text);
        }
        return rv;
    }

    /* Palette of up to 8 question chips */
    void palette(JSONArray st, int cur, float x, float y) {
        int n = st == null ? 8 : st.length();
        int show = Math.min(8, n);
        int from = Math.max(0, Math.min(cur - 3, n - show));
        float cell = Math.min(27, (W - 32 - 7 * 5) / 8f), gap = 5;
        for (int i = 0; i < show; i++) {
            int q = from + i;
            int v = st == null ? 0 : st.optInt(q, 0);
            float cxp = x + i * (cell + gap);
            int fillC, lineC, txtC;
            if (q == cur) { fillC = 0xFF2F6BEA; lineC = fillC; txtC = 0xFFFFFFFF; }
            else if (v == 1) { fillC = p.dark ? 0xFF16382A : 0xFFE6F6EC; lineC = p.green; txtC = p.green; }
            else if (v == 2) { fillC = p.dark ? 0xFF3B2220 : 0xFFFFE4DF; lineC = p.red; txtC = p.red; }
            else { fillC = p.dark ? 0xFF1E2438 : 0xFFF2F4FA; lineC = p.dark ? 0xFF3A425F : 0xFFD3D9E8; txtC = p.sec; }
            rr(cxp, y, cell, cell, 8, fillC);
            line(cxp + 0.75f, y + 0.75f, cell - 1.5f, cell - 1.5f, 7.5f, lineC, 1.5f);
            text(String.valueOf(q + 1), cxp + cell / 2f, y + cell / 2f + 4f, sora, 11, txtC, Paint.Align.CENTER, 0);
        }
    }

    /* Practice 4x2 */
    static RemoteViews practice(Context c, JSONObject s, Wg.P p, int w, int h) {
        WgArt a = new WgArt(c, p, w, h);
        a.card();
        JSONObject r = s == null ? null : s.optJSONObject("resume");
        a.mark(16, 14, 22);
        String title, big, cap, btn, right = "";
        JSONArray pl = null;
        int ix = -1;
        String uri;
        if (r == null) {
            title = "Practice"; big = "Ready"; cap = "Start a timed set"; btn = "Start"; uri = "ascend://practice";
        } else {
            int dn = r.optInt("dn"), t = Math.max(1, r.optInt("t")), sk = r.optInt("sk");
            ix = r.optInt("ix");
            pl = r.optJSONArray("pl");
            title = r.optString("n", "Session");
            right = "Q " + (ix + 1) + " of " + t;
            big = dn + " of " + t;
            cap = "answered" + (sk > 0 ? " · " + sk + " skipped" : "");
            btn = "Continue"; uri = "ascend://resume";
        }
        float rw = right.length() == 0 ? 0 : a.tw(right, a.sora, 10.5f) + 8;
        a.text(title, 46, 31, a.lexB, 16, p.text, Paint.Align.LEFT, w - 46 - 16 - rw);
        a.text(right, w - 16, 30, a.sora, 10.5f, p.sec, Paint.Align.RIGHT, 0);
        a.palette(pl, ix, 16, 48);
        float bw = 98, bh = 38;
        a.pillBtn(btn, w - 16 - bw, h - 14 - bh, bw, bh);
        float mw = w - 16 - bw - 16 - 8;
        float z = a.sizeFor(big, a.unb, 22, 12, mw);
        a.text(big, 16, h - 36, a.unb, z, p.text, Paint.Align.LEFT, 0);
        a.text(cap, 16, h - 17, a.lexR, 11, p.sec, Paint.Align.LEFT, mw);
        return shell(c, R.layout.w_art, a, "Practice. " + big, uri);
    }

    /* Resume 4x1 */
    static RemoteViews resume(Context c, JSONObject s, Wg.P p, int w, int h) {
        WgArt a = new WgArt(c, p, w, h);
        a.card();
        JSONObject r = s == null ? null : s.optJSONObject("resume");
        String label, title, sub, btn, uri;
        float frac = 0f;
        if (r == null) {
            label = "Practice"; title = "No unfinished session"; sub = "Start a timed set"; btn = "Start"; uri = "ascend://practice";
        } else {
            int dn = r.optInt("dn"), t = Math.max(1, r.optInt("t"));
            frac = (float) dn / t;
            label = "Unfinished " + r.optString("k", "session").toLowerCase(Locale.US);
            title = r.optString("n", "Session");
            sub = dn + " of " + t + " answered"; btn = "Continue"; uri = "ascend://resume";
        }
        float diam = Math.min(46, h - 20);
        a.ring(16 + diam / 2f, h / 2f, diam, frac, true, false);
        a.mark(16 + diam / 2f - 8, h / 2f - 8, 16);
        float bw = 88, bh = 32;
        float x0 = 16 + diam + 14, tw = w - x0 - 16 - bw - 10;
        a.caps(label, x0, h / 2f - 12, 9.5f, p.sec, Paint.Align.LEFT, tw);
        a.text(title, x0, h / 2f + 5, a.lexB, 14, p.text, Paint.Align.LEFT, tw);
        a.text(sub, x0, h / 2f + 21, a.lexR, 11, p.sec, Paint.Align.LEFT, tw);
        a.pillBtn(btn, w - 16 - bw, (h - bh) / 2f, bw, bh);
        return shell(c, R.layout.w_art, a, label + ". " + title, uri);
    }

    /* Target 2x2 */
    static RemoteViews target(Context c, JSONObject s, Wg.P p, int w, int h) {
        WgArt a = new WgArt(c, p, w, h);
        a.card();
        JSONObject ex = s == null ? null : s.optJSONObject("exam");
        JSONObject f = s == null ? null : s.optJSONObject("focus");
        int st = f == null ? 0 : f.optInt("st");
        a.mark(w - 14 - 20, 14, 20);
        String label, days, sub;
        if (ex == null) {
            label = "Target"; days = "–"; sub = "Set a date in Plan";
        } else {
            label = ex.optString("n", "Target");
            int dd = ex.optInt("days");
            days = String.valueOf(dd);
            sub = (dd == 1 ? "day to go" : "days to go") + (st > 0 ? " · " + st + "d" : "");
        }
        a.caps(label, 14, 28, 10, p.sec, Paint.Align.LEFT, w - 14 - 20 - 14 - 10);
        float z = a.sizeFor(days, a.unb, 36, 18, w - 28);
        a.text(days, 14, 68, a.unb, z, p.text, Paint.Align.LEFT, 0);
        a.text(sub, 14, 86, a.lexR, 11.5f, p.sec, Paint.Align.LEFT, w - 28);
        double[] v = new double[7];
        StringBuilder letters = new StringBuilder();
        JSONArray wk = f == null ? null : f.optJSONArray("wk");
        JSONArray dw = f == null ? null : f.optJSONArray("dw");
        String names = "SMTWTFS";
        for (int i = 0; i < 7; i++) {
            v[i] = wk == null ? 0 : wk.optDouble(i, 0);
            int dx = dw == null ? i : dw.optInt(i, i);
            letters.append(names.charAt(((dx % 7) + 7) % 7));
        }
        double mx = 1;
        for (double dv : v) mx = Math.max(mx, dv);
        float gap = 5, bw = (w - 28 - gap * 6) / 7f, base = h - 26, top = Math.max(98, base - 34);
        for (int i = 0; i < 7; i++) {
            float x = 14 + i * (bw + gap);
            float bh = (float) Math.max(3, (base - top) * v[i] / mx);
            if (i == 6) a.grad(x, base - bh, bw, bh, 3, a.a1, a.a2);
            else a.rr(x, base - bh, bw, bh, 3, p.dark ? 0xFF4A4C86 : 0xFFC9D2F2);
            a.text(String.valueOf(letters.charAt(i)), x + bw / 2f, h - 11, a.lexR, 10, p.sec, Paint.Align.CENTER, 0);
        }
        return shell(c, R.layout.w_art, a, label + ", " + days + " days", "ascend://tracker");
    }

    /* Revise next 4x2 */
    static RemoteViews revise(Context c, JSONObject s, Wg.P p, int w, int h) {
        WgArt a = new WgArt(c, p, w, h);
        a.card();
        a.mark(16, 14, 20);
        a.caps("Revise next", 44, 28, 10, p.sec, Paint.Align.LEFT, w - 60);
        JSONObject rv0 = s == null ? null : s.optJSONObject("rev");
        JSONObject top = rv0 == null ? null : rv0.optJSONObject("top");
        float bw = 90, bh = 36;
        float tw = w - 16 - bw - 16 - 12;
        String title, sub;
        List<String> chips = new ArrayList<String>();
        List<Integer> cols = new ArrayList<Integer>();
        if (top == null) {
            title = s == null ? "Open Ascend to set up" : "All caught up";
            sub = s == null ? "" : "Nothing needs revising";
        } else {
            title = top.optString("c");
            sub = top.optString("s");
            int y = top.optInt("y"), wr = top.optInt("w");
            if (y > 0) { chips.add(y + " not revised"); cols.add(p.text); }
            if (wr > 0) { chips.add(wr + " wrong"); cols.add(p.red); }
        }
        JSONObject m = s == null ? null : s.optJSONObject("mist");
        int mw = m == null ? 0 : m.optInt("w"), ms = m == null ? 0 : m.optInt("s");
        if (mw + ms > 0) { chips.add("Mistakes: " + mw + " wrong, " + ms + " skipped"); cols.add(p.text); }
        float z = a.sizeFor(title, a.lexB, 19, 13, tw);
        a.text(title, 16, 62, a.lexB, z, p.text, Paint.Align.LEFT, tw);
        a.text(sub, 16, 80, a.lexR, 12, p.sec, Paint.Align.LEFT, tw);
        a.pillBtn("Revise", w - 16 - bw, 42, bw, bh);
        float cx = 16, cy = 96, ch = 24;
        for (int i = 0; i < chips.size(); i++) {
            float cwid = a.tw(chips.get(i), a.lexR, 11.5f) + 20;
            if (cx + cwid > w - 16 && cx > 16) { cx = 16; cy += ch + 6; }
            if (cy + ch > h - 8) break;
            a.chip(cx, cy, chips.get(i), cols.get(i), ch);
            cx += cwid + 6;
        }
        return shell(c, R.layout.w_art, a, "Revise next. " + title, "ascend://revision");
    }
}
