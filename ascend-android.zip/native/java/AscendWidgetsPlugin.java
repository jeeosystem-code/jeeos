package com.ascend.study;

import android.content.pm.PackageInfo;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Window;
import android.view.WindowManager;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/** The web app calls AscendWidgets.save({json}) every time its summary changes. */
@CapacitorPlugin(name = "AscendWidgets")
public class AscendWidgetsPlugin extends Plugin {
    @PluginMethod
    public void save(PluginCall call) {
        String j = call.getString("json");
        if (j == null) {
            call.reject("no json");
            return;
        }
        try {
            Wg.store(getContext(), j);
            Wg.refreshAll(getContext());
        } catch (Exception e) {
            call.reject("widget update failed");
            return;
        }
        call.resolve();
    }

    private boolean zenKeep = false, awakeKeep = false;

    /** Keeps the display on while a practice session runs (it is released again when on is false). */
    @PluginMethod
    public void awake(final PluginCall call) {
        final boolean on = Boolean.TRUE.equals(call.getBoolean("on", false));
        getActivity().runOnUiThread(new Runnable() {
            public void run() {
                try {
                    awakeKeep = on;
                    Window w = getActivity().getWindow();
                    if (on || zenKeep) w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    else w.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                } catch (Exception e) {
                }
                call.resolve();
            }
        });
    }

    /** Zen screen: keep the display on and hide the system bars; brightness stays with the phone (adaptive) unless b is 0 to 1. Undone when on is false. */
    @PluginMethod
    public void zen(final PluginCall call) {
        final boolean on = Boolean.TRUE.equals(call.getBoolean("on", false));
        final double lvl = call.getData().optDouble("b", -1);
        getActivity().runOnUiThread(new Runnable() {
            public void run() {
                try {
                    Window w = getActivity().getWindow();
                    WindowManager.LayoutParams lp = w.getAttributes();
                    WindowInsetsControllerCompat c = WindowCompat.getInsetsController(w, w.getDecorView());
                    zenKeep = on;
                    if (on) {
                        w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                        lp.screenBrightness = lvl >= 0 ? (float) Math.max(0.01, Math.min(1.0, lvl)) : WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE;
                        if (c != null) {
                            c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                            c.hide(WindowInsetsCompat.Type.systemBars());
                        }
                    } else {
                        if (!awakeKeep) w.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                        lp.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE;
                        if (c != null) c.show(WindowInsetsCompat.Type.systemBars());
                    }
                    w.setAttributes(lp);
                } catch (Exception e) {
                }
                call.resolve();
            }
        });
    }

    /** Temporary: device details and a fresh build check of all widgets, for the Diagnostics screen. */
    @PluginMethod
    public void diag(final PluginCall call) {
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            public void run() {
                try {
                    JSObject o = new JSObject();
                    o.put("device", Build.MANUFACTURER + " " + Build.MODEL);
                    o.put("sdk", Build.VERSION.SDK_INT);
                    try {
                        PackageInfo pi = getContext().getPackageManager().getPackageInfo(getContext().getPackageName(), 0);
                        o.put("app", pi.versionName + " (" + pi.versionCode + ")");
                    } catch (Exception e) {
                        o.put("app", "?");
                    }
                    o.put("widgets", Wg.testAll(getContext()));
                    call.resolve(o);
                } catch (Throwable e) {
                    call.reject("diag failed: " + e);
                }
            }
        });
    }
}
