package com.ascend.study;

import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/** The web app calls AscendWidgets.save({json}) every time its summary changes. */
@CapacitorPlugin(name = "AscendWidgets")
public class AscendWidgetsPlugin extends Plugin {
    @PluginMethod
    public void save(PluginCall call) {
        String j = call.getString("json");
        if (j == null) {
            call.reject("no json");
            return;
        }
        try {
            Wg.store(getContext(), j);
            Wg.refreshAll(getContext());
        } catch (Exception e) {
            call.reject("widget update failed");
            return;
        }
        call.resolve();
    }
}
