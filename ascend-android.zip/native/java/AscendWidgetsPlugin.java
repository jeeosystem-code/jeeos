package com.ascend.study;

import android.content.pm.PackageInfo;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/** The web app calls AscendWidgets.save({json}) every time its summary changes. */
@CapacitorPlugin(name = "AscendWidgets")
public class AscendWidgetsPlugin extends Plugin {
    @PluginMethod
    public void save(PluginCall call) {
        String j = call.getString("json");
        if (j == null) {
            call.reject("no json");
            return;
        }
        try {
            Wg.store(getContext(), j);
            Wg.refreshAll(getContext());
        } catch (Exception e) {
            call.reject("widget update failed");
            return;
        }
        call.resolve();
    }

    /** Temporary: device details and a fresh build check of all widgets, for the Diagnostics screen. */
    @PluginMethod
    public void diag(final PluginCall call) {
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            public void run() {
                try {
                    JSObject o = new JSObject();
                    o.put("device", Build.MANUFACTURER + " " + Build.MODEL);
                    o.put("sdk", Build.VERSION.SDK_INT);
                    try {
                        PackageInfo pi = getContext().getPackageManager().getPackageInfo(getContext().getPackageName(), 0);
                        o.put("app", pi.versionName + " (" + pi.versionCode + ")");
                    } catch (Exception e) {
                        o.put("app", "?");
                    }
                    o.put("widgets", Wg.testAll(getContext()));
                    call.resolve(o);
                } catch (Throwable e) {
                    call.reject("diag failed: " + e);
                }
            }
        });
    }
}
