# Ascend – build the Android app (APK) with GitHub

You need only a browser. No coding, no Android Studio.

1. Create a free account at github.com, then click **New repository**. Name it `ascend`, keep it **Private**, click **Create**.
2. On the new repository page click **uploading an existing file**. Unzip `ascend-android.zip` on your computer, open the folder and drag **everything inside it** (including the `.github` folder, `src`, `assets`, `scripts`, `package.json`, `capacitor.config.json`) into the page. Click **Commit changes**.
   - If the `.github` folder does not appear on your computer, turn on "show hidden files".
3. Open the **Actions** tab. If asked, click "I understand my workflows, enable them".
4. Click **Build Ascend APK** on the left, then **Run workflow** (green button). Wait 6–10 minutes.
5. Open the finished run. At the bottom, under **Artifacts**, download **Ascend-APK**. Unzip it to get `app-debug.apk`.
6. Send `app-debug.apk` to the phone (WhatsApp, Drive, cable). Tap it, allow "install unknown apps" when asked, and install.

## Updating the app later
Replace `src/index.html` in the repository with the new version of the app file and commit. The build runs again by itself; download the new APK from Actions.

## Notes
- This is a "debug" APK. It installs fine on any phone for sharing with colleagues. For the Play Store a signed release build is needed (ask Claude to add it).
- The app name is Ascend, package id `com.ascend.study`. Change both in `capacitor.config.json` before the first build if you want something else. Changing the id later makes phones treat it as a different app.
- Student data lives on the phone. Uninstalling the app erases it unless the student has signed in and backed up.
