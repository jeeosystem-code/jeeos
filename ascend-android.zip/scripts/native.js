// Runs after "npx cap add android": brand the native project (icon, splash, permissions).
const fs = require("fs"), path = require("path");
const root = path.resolve(__dirname, "..");
const app = path.join(root, "android", "app", "src", "main");
const res = path.join(app, "res");
if (!fs.existsSync(app)) { console.error("android project not found - run 'npx cap add android' first"); process.exit(1); }

function copyDir(from, to) {
  fs.mkdirSync(to, { recursive: true });
  for (const f of fs.readdirSync(from)) {
    const s = path.join(from, f), d = path.join(to, f);
    fs.statSync(s).isDirectory() ? copyDir(s, d) : fs.copyFileSync(s, d);
  }
}

// 1. icons, splash icon, colours
copyDir(path.join(root, "res"), res);
fs.writeFileSync(path.join(res, "values", "ic_launcher_background.xml"),
  '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#5E5CE6</color>\n</resources>\n');

// 2. launch theme = native splash (same background and icon position as the in-app splash)
const stylesPath = path.join(res, "values", "styles.xml");
let styles = fs.readFileSync(stylesPath, "utf8");
const launch = `<style name="AppTheme.NoActionBarLaunch" parent="Theme.SplashScreen">
        <item name="windowSplashScreenBackground">@color/ascend_splash_bg</item>
        <item name="windowSplashScreenAnimatedIcon">@drawable/splash_icon</item>
        <item name="postSplashScreenTheme">@style/AppTheme.NoActionBar</item>
    </style>`;
if (/<style name="AppTheme.NoActionBarLaunch"[\s\S]*?<\/style>/.test(styles)) {
  styles = styles.replace(/<style name="AppTheme.NoActionBarLaunch"[\s\S]*?<\/style>/, launch);
} else {
  styles = styles.replace("</resources>", "    " + launch + "\n</resources>");
}
fs.writeFileSync(stylesPath, styles);

// 3. vibration for haptics
const manPath = path.join(app, "AndroidManifest.xml");
let man = fs.readFileSync(manPath, "utf8");
if (!man.includes("android.permission.VIBRATE")) {
  man = man.replace("</manifest>", '    <uses-permission android:name="android.permission.VIBRATE" />\n</manifest>');
  fs.writeFileSync(manPath, man);
}

// 4. widgets: Java sources, resources, receivers and the ascend:// link
const cfg = JSON.parse(fs.readFileSync(path.join(root, "capacitor.config.json"), "utf8"));
const javaDir = path.join(app, "java", ...cfg.appId.split("."));
copyDir(path.join(root, "native", "java"), javaDir);
copyDir(path.join(root, "native", "res"), res);
man = fs.readFileSync(manPath, "utf8");
if (!man.includes("TodayWidget")) {
  const rcv = ["Today", "Focus", "Resume", "Target", "Revise"].map(function (k) {
    return '        <receiver android:name="' + cfg.appId + "." + k + 'Widget" android:exported="true">\n' +
      '            <intent-filter><action android:name="android.appwidget.action.APPWIDGET_UPDATE" /></intent-filter>\n' +
      '            <meta-data android:name="android.appwidget.provider" android:resource="@xml/' + k.toLowerCase() + '_widget_info" />\n' +
      "        </receiver>\n";
  }).join("");
  man = man.replace("</application>", rcv + "    </application>");
}
if (!man.includes('android:scheme="ascend"')) {
  const link = '            <intent-filter>\n' +
    '                <action android:name="android.intent.action.VIEW" />\n' +
    '                <category android:name="android.intent.category.DEFAULT" />\n' +
    '                <category android:name="android.intent.category.BROWSABLE" />\n' +
    '                <data android:scheme="ascend" />\n' +
    '            </intent-filter>\n        </activity>';
  man = man.replace("</activity>", link);
}
fs.writeFileSync(manPath, man);
console.log("Ascend native branding applied");
