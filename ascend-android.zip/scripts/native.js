// Adds the home-screen widgets to the generated Android project (run after "npx cap add android").
const fs = require("fs"), path = require("path");
const root = path.join(__dirname, "..");
const app = path.join(root, "android", "app", "src", "main");
function copyDir(from, to) {
  fs.mkdirSync(to, { recursive: true });
  for (const f of fs.readdirSync(from)) {
    const a = path.join(from, f), b = path.join(to, f);
    if (fs.statSync(a).isDirectory()) copyDir(a, b); else fs.copyFileSync(a, b);
  }
}
copyDir(path.join(root, "native", "java"), path.join(app, "java"));
copyDir(path.join(root, "native", "res"), path.join(app, "res"));
const mp = path.join(app, "AndroidManifest.xml");
let m = fs.readFileSync(mp, "utf8");
if (m.indexOf("ascend://") < 0 && m.indexOf('android:scheme="ascend"') < 0) {
  const link = '<intent-filter><action android:name="android.intent.action.VIEW"/><category android:name="android.intent.category.DEFAULT"/><category android:name="android.intent.category.BROWSABLE"/><data android:scheme="ascend"/></intent-filter>\n        </activity>';
  if (m.indexOf("</activity>") < 0) throw new Error("no </activity> in manifest");
  m = m.replace("</activity>", link);
  const names = ["Today", "Focus", "Resume", "Countdown", "Week", "Mistakes", "Test", "Revision", "Homework", "Shortcuts"];
  const files = ["today", "focus", "resume", "countdown", "week", "mistakes", "test", "revision", "homework", "shortcuts"];
  const rc = names.map((n, i) => '<receiver android:name=".W' + n + '" android:exported="true"><intent-filter><action android:name="android.appwidget.action.APPWIDGET_UPDATE"/></intent-filter><meta-data android:name="android.appwidget.provider" android:resource="@xml/wg_' + files[i] + '_info"/></receiver>').join("\n        ");
  m = m.replace("</application>", "    " + rc + "\n    </application>");
  fs.writeFileSync(mp, m);
}
console.log("widgets added");
