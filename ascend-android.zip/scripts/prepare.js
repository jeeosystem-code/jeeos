// Builds www/ from src/index.html: bundles the Inter font so the app looks the same offline.
const fs = require("fs"), path = require("path");
const root = path.join(__dirname, "..");
const www = path.join(root, "www"), fonts = path.join(www, "fonts");
fs.rmSync(www, { recursive: true, force: true });
fs.mkdirSync(fonts, { recursive: true });
let html = fs.readFileSync(path.join(root, "src", "index.html"), "utf8");
// remove Google Fonts links
html = html.replace(/<link[^>]*fonts\.(googleapis|gstatic)\.com[^>]*>\s*/g, "");
let css = "";
[400, 500, 600, 700, 800].forEach(function (w) {
  const f = "inter-latin-" + w + "-normal.woff2";
  const src = path.join(root, "node_modules", "@fontsource", "inter", "files", f);
  if (!fs.existsSync(src)) { console.warn("missing font file", f); return; }
  fs.copyFileSync(src, path.join(fonts, f));
  css += "@font-face{font-family:Inter;font-style:normal;font-weight:" + w + ";font-display:swap;src:url(fonts/" + f + ") format('woff2')}\n";
});
const i = html.indexOf("<style");
if (i < 0) throw new Error("no <style> found");
const j = html.indexOf(">", i) + 1;
html = html.slice(0, j) + "\n" + css + html.slice(j);
fs.writeFileSync(path.join(www, "index.html"), html);
console.log("www/index.html ready,", Math.round(html.length / 1024), "KB");
